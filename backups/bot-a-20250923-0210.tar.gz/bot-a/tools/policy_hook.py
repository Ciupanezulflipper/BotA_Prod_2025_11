#!/usr/bin/env python3
"""
Unified strategy policy hook:
- MACD direction veto (already present)
- ADX trend bonus
- RSI regime filter (optional)
- Higher-timeframe (HTF) alignment (optional, by resample)
- News mute (optional) via data/news_schedule.csv
- Per-pair cooldown (optional), file-based

Inputs:
    apply_policy(candles, dir_hint, base_score, pair, tf, now_utc=None)

Outputs (dict):
    {
      "score_delta": float,
      "veto": bool,
      "tags": [..],
      "notes": [..],
      "telemetry": {...}
    }
"""

from __future__ import annotations
import os, csv, math, time
from datetime import datetime, timedelta, timezone
from typing import List, Dict, Any, Optional

# --------- small utils (no external deps) ----------
def ema(series: List[float], span: int) -> List[float]:
    if not series or span <= 1: return series[:]
    k = 2 / (span + 1)
    out = [series[0]]
    for x in series[1:]:
        out.append(out[-1] + k * (x - out[-1]))
    return out

def rsi(closes: List[float], period: int=14) -> List[float]:
    if len(closes) < period + 1: return [50.0]*len(closes)
    gains, losses = [], []
    for i in range(1, period+1):
        ch = closes[i] - closes[i-1]
        gains.append(max(ch,0)); losses.append(max(-ch,0))
    avg_gain = sum(gains)/period
    avg_loss = sum(losses)/period
    rsis = [50.0]*(period)  # pad
    for i in range(period+1, len(closes)):
        ch = closes[i] - closes[i-1]
        gain = max(ch,0); loss = max(-ch,0)
        avg_gain = (avg_gain*(period-1) + gain)/period
        avg_loss = (avg_loss*(period-1) + loss)/period
        rs = (avg_gain / avg_loss) if avg_loss>1e-12 else 1e9
        val = 100 - (100/(1+rs))
        rsis.append(val)
    # ensure same length
    while len(rsis) < len(closes):
        rsis.append(rsis[-1] if rsis else 50.0)
    return rsis[:len(closes)]

def macd(closes: List[float], fast=12, slow=26, signal=9):
    if len(closes) < slow+signal+5:
        return ([0.0]*len(closes), [0.0]*len(closes))
    ema_fast = ema(closes, fast)
    ema_slow = ema(closes, slow)
    macd_line = [f-s for f,s in zip(ema_fast, ema_slow)]
    sig_line  = ema(macd_line, signal)
    return (macd_line, sig_line)

def adx_from_hlcl(highs: List[float], lows: List[float], closes: List[float], period: int=14) -> List[float]:
    # very compact ADX (Wilder)
    n = len(closes)
    if n < period+2: return [18.0]*n
    tr, plus_dm, minus_dm = [0.0]*n, [0.0]*n, [0.0]*n
    for i in range(1,n):
        up = highs[i]-highs[i-1]; dn = lows[i-1]-lows[i]
        plus_dm[i]  = up if (up>dn and up>0) else 0.0
        minus_dm[i] = dn if (dn>up and dn>0) else 0.0
        tr[i] = max(highs[i]-lows[i], abs(highs[i]-closes[i-1]), abs(lows[i]-closes[i-1]))
    def rma(arr):
        out=[0.0]*n; out[period]=sum(arr[1:period+1])/period
        alpha=1/period
        for i in range(period+1,n):
            out[i]=out[i-1]+alpha*(arr[i]-out[i-1])
        return out
    trn = rma(tr); pdm=rma(plus_dm); mdm=rma(minus_dm)
    plus_di  = [0.0 if trn[i]==0 else 100*pdm[i]/trn[i] for i in range(n)]
    minus_di = [0.0 if trn[i]==0 else 100*mdm[i]/trn[i] for i in range(n)]
    dx = [0.0]*n
    for i in range(n):
        s=plus_di[i]+minus_di[i]
        dx[i] = 0.0 if s==0 else 100*abs(plus_di[i]-minus_di[i])/s
    adx=[0.0]*n; adx[period]=sum(dx[1:period+1])/period
    for i in range(period+1,n):
        adx[i]=(adx[i-1]*(period-1)+dx[i])/period
    return adx

def tf_to_minutes(tf: str) -> int:
    tf=tf.upper()
    if tf.startswith("M"): return int(tf[1:])
    if tf.startswith("H"): return int(tf[1:])*60
    if tf=="D1": return 1440
    return 15

def resample_htf(closes, highs, lows, times, mult: int):
    # group each 'mult' bars to one HTF bar (simple O/H/L/C)
    if mult<=1 or len(closes)<mult: 
        return closes, highs, lows, times
    R = len(closes)//mult
    rc,rh,rl,rt=[],[],[],[]
    for k in range(R):
        s=k*mult; e=s+mult
        chunk_c = closes[s:e]; chunk_h=highs[s:e]; chunk_l=lows[s:e]; chunk_t=times[s:e]
        rc.append(chunk_c[-1])
        rh.append(max(chunk_h)); rl.append(min(chunk_l)); rt.append(chunk_t[-1])
    return rc,rh,rl,rt

def read_env_bool(name:str, default:bool) -> bool:
    v=os.environ.get(name, str(int(default))).strip()
    return v in ("1","true","TRUE","yes","Yes")

def read_env_int(name:str, default:int) -> int:
    try: return int(os.environ.get(name, str(default)))
    except: return default

def read_env_float(name:str, default:float) -> float:
    try: return float(os.environ.get(name, str(default)))
    except: return default

def now_utc_ts() -> float:
    return time.time()

def parse_ts_z(s: str) -> Optional[datetime]:
    try:
        if s.endswith("Z"): s=s[:-1]+"+00:00"
        return datetime.fromisoformat(s).astimezone(timezone.utc)
    except: return None

# cooldown store per pair+tf
def cooldown_path(pair:str, tf:str) -> str:
    base = os.path.expanduser("~/bot-a/data")
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, f"last_send_{pair}_{tf}.ts")

def last_send_minutes(pair:str, tf:str, now_ts:float) -> Optional[float]:
    p=cooldown_path(pair,tf)
    if not os.path.exists(p): return None
    try:
        with open(p,"r") as f:
            t=float(f.read().strip())
        return (now_ts - t)/60.0
    except: return None

def save_last_send(pair:str, tf:str, now_ts:float):
    p=cooldown_path(pair,tf)
    with open(p,"w") as f:
        f.write(str(now_ts))

def news_in_window(now_dt: datetime, before_min:int, after_min:int) -> Optional[str]:
    path=os.path.expanduser("~/bot-a/data/news_schedule.csv")
    if not os.path.exists(path): return None
    window_before = timedelta(minutes=before_min)
    window_after  = timedelta(minutes=after_min)
    try:
        with open(path,"r", newline="") as f:
            rdr=csv.DictReader(f)
            for row in rdr:
                ts = parse_ts_z((row.get("ts") or "").strip())
                if not ts: continue
                if ts - window_before <= now_dt <= ts + window_after:
                    ev = row.get("event","news").strip()
                    imp = (row.get("impact","").strip().lower())
                    return f"{ev} ({imp or 'n/a'})"
    except: 
        return None
    return None

# ------------- MAIN HOOK ----------------
def apply_policy(candles: List[Dict[str,Any]],
                 dir_hint: str,
                 base_score: float,
                 pair: str,
                 tf: str,
                 now_utc: Optional[datetime]=None) -> Dict[str,Any]:

    tags, notes = [], []
    veto=False
    delta=0.0
    now_dt = now_utc or datetime.now(timezone.utc)
    now_ts = now_dt.timestamp()

    if not candles or len(candles)<50:
        return {"score_delta":0.0, "veto":True, "tags":["no-data"], "notes":["insufficient candles"], "telemetry":{}}

    closes=[float(c.get("close",c.get("c"))) for c in candles]
    highs =[float(c.get("high",c.get("h")))  for c in candles]
    lows  =[float(c.get("low",c.get("l")))   for c in candles]
    # support both iso ts and epoch ts
    times=[]
    for c in candles:
        t=c.get("time") or c.get("t")
        if isinstance(t,(int,float)): times.append(t)
        else:
            dt=parse_ts_z(str(t)) or now_dt
            times.append(dt.timestamp())

    # --- MACD veto & tag ---
    macd_line, sig = macd(closes)
    macd_now = macd_line[-1] - sig[-1]
    macd_dir = "up" if macd_now>=0 else "down"
    tags.append("MACD↑" if macd_now>=0 else "MACD↓")

    dir_hint = (dir_hint or "").lower()
    if (dir_hint=="long" and macd_now<0) or (dir_hint=="short" and macd_now>0):
        veto=True; notes.append("MACD opposes dir_hint → veto")

    # --- ADX bonus ---
    adx = adx_from_hlcl(highs,lows,closes)
    adx_now = adx[-1]
    if adx_now >= 18:
        b = 0.2 if adx_now<22 else 0.6 if adx_now>=28 else 0.4
        delta += b
        tags.append("ADX✓"); notes.append(f"ADX {adx_now:.1f}≥18 → +{b:.2f}")
    else:
        notes.append(f"ADX {adx_now:.1f}<18 → no trend bonus")

    # --- RSI regime filter (optional) ---
    if read_env_bool("POLICY_USE_RSI", True):
        rsi_now = rsi(closes)[-1]
        rsi_min = read_env_int("POLICY_RSI_MIN", 50)
        tags.append(f"RSI{int(round(rsi_now))}")
        if dir_hint=="long" and rsi_now < rsi_min:
            veto=True; notes.append(f"RSI {rsi_now:.1f}<{rsi_min} for LONG → veto")
        if dir_hint=="short" and rsi_now > (100-rsi_min):
            veto=True; notes.append(f"RSI {rsi_now:.1f}>{100-rsi_min} for SHORT → veto")
        # strong regime bump
        strong_bump = read_env_float("POLICY_STRONG_BUMP", 0.3)
        if rsi_now>=60 and adx_now>=22:
            delta += strong_bump
            notes.append(f"Strong regime RSI≥60 & ADX≥22 → +{strong_bump:.2f}")

    # --- HTF alignment (optional, resample N*x TF) ---
    if read_env_bool("POLICY_USE_HTF", True):
        mult = read_env_int("POLICY_HTF_MULT", 4)
        htc, hth, htl, htt = resample_htf(closes, highs, lows, times, mult)
        if len(htc)>=50:
            ema50 = ema(htc, 50)[-1]
            lastc = htc[-1]
            agree_long  = lastc >= ema50
            agree_short = lastc <= ema50
            if dir_hint=="long" and not agree_long:
                veto=True; notes.append("HTF misaligned (price<EMA50)")
            if dir_hint=="short" and not agree_short:
                veto=True; notes.append("HTF misaligned (price>EMA50)")
            tags.append("HTF✓" if ((dir_hint=="long" and agree_long) or (dir_hint=="short" and agree_short)) else "HTF×")
        else:
            notes.append("HTF sample too small, skipping")

    # --- News mute (optional) ---
    if read_env_bool("POLICY_USE_NEWS_MUTE", True):
        nb = read_env_int("POLICY_NEWS_BEFORE_MIN", 30)
        na = read_env_int("POLICY_NEWS_AFTER_MIN", 30)
        ev = news_in_window(now_dt, nb, na)
        if ev:
            veto=True; tags.append("NEWS-MUTE"); notes.append(f"News window: {ev}")

    # --- Cooldown (optional) ---
    if read_env_bool("POLICY_USE_COOLDOWN", True):
        mins = read_env_int("POLICY_COOLDOWN_MIN", 20)
        since = last_send_minutes(pair, tf, now_ts)
        if since is not None and since < mins:
            veto=True; tags.append("cooldown"); notes.append(f"Cooldown {since:.1f}min<{mins}min")
        # NOTE: saving last_send() must be done by the sender AFTER a send.
        # If your sender already persists last-send, don't do it here.

    return {
        "score_delta": round(delta, 6),
        "veto": bool(veto),
        "tags": tags,
        "notes": notes,
        "telemetry": {
            "last_macd_diff": round(macd_now, 10),
            "last_adx": round(adx_now, 2),
            "base_score": base_score,
            "dir_hint": dir_hint,
            "pair": pair,
            "tf": tf
        }
    }
