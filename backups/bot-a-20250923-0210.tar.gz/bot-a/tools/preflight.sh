#!/data/data/com.termux/files/usr/bin/bash
set -e
ENV="$HOME/.env"
REQ=(WATCHLIST CONF_MIN STRONG_SEND_THRESHOLD TELEGRAM_TOKEN)
miss=()
for k in "${REQ[@]}"; do grep -q "^$k=" "$ENV" || miss+=("$k"); done
if [ ${#miss[@]} -gt 0 ]; then
  python3 "$HOME/bot-a/tools/status_cmd.py" --alert "Preflight FAIL: missing ${miss[*]}" || true
  exit 1
fi
python3 "$HOME/bot-a/tools/status_cmd.py" --alert "Preflight OK ($(date -Is))" || true
