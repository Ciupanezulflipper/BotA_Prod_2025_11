#!/usr/bin/env python3
"""
Robust news sentiment helper:
- If dependencies or network are missing, returns a neutral result and exit 0.
- Prints a compact single-line JSON for easy parsing by other scripts.
"""
from __future__ import annotations
import json, sys, time

def safe_print(payload: dict):
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()

def main():
    base = {
        "ok": True,
        "source": "news_sentiment.py",
        "score": 0.0,        # neutral 0..1
        "samples": 0,
        "reason": "neutral-fallback",
        "ts": int(time.time())
    }
    try:
        try:
            import requests  # type: ignore
        except Exception:
            safe_print(base | {"ok": True, "reason": "requests-missing"})
            return 0

        # If you have a real API, drop it here; keep robust timeouts.
        # This placeholder intentionally avoids outbound calls at sea.
        safe_print(base | {"ok": True, "reason": "offline-mode"})
        return 0

    except Exception as e:
        safe_print({"ok": True, "score": 0.0, "samples": 0,
                    "reason": f"graceful-error:{type(e).__name__}", "ts": int(time.time())})
        return 0

if __name__ == "__main__":
    sys.exit(main())
