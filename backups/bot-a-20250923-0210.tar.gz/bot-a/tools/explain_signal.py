#!/usr/bin/env python3
"""
explain_signal.py
Show exactly WHY a signal did or did not trigger for a pair+tf,
using your existing policy_hook.apply_policy and the latest CSV
candles saved in ~/bot-a/data/candles/{PAIR}_{TF}.csv

Usage:
  python3 explain_signal.py EURUSD M15
  python3 explain_signal.py EURUSD H1
"""

import sys, os, csv, time
from datetime import datetime, timezone
from policy_hook import apply_policy  # uses your current strong policy

DATA_DIR = os.path.expanduser("~/bot-a/data/candles")

def load_csv(pair:str, tf:str, limit:int=200):
    path = os.path.join(DATA_DIR, f"{pair}_{tf}.csv")
    if not os.path.exists(path):
        print(f"[ERROR] No candles file: {path}")
        sys.exit(2)
    rows=[]
    with open(path, "r") as f:
        r = csv.DictReader(f)
        for row in r:
            try:
                # accept either epoch or ISO-ish
                t = row.get("time") or row.get("timestamp") or row.get("date")
                if t is None:
                    continue
                if str(t).isdigit():
                    ts = int(t)
                else:
                    # try parse common "%Y-%m-%d %H:%M:%S"
                    ts = int(datetime.strptime(t.split(".")[0], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc).timestamp())
                rows.append({
                    "time": ts,
                    "open": float(row["open"]),
                    "high": float(row["high"]),
                    "low" : float(row["low"]),
                    "close": float(row["close"])
                })
            except Exception as e:
                # skip bad rows
                pass
    if not rows:
        print(f"[ERROR] Empty/invalid CSV: {path}")
        sys.exit(2)
    rows = sorted(rows, key=lambda x: x["time"])
    return rows[-limit:]

def fmt_ts(ts:int):
    return datetime.utcfromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S UTC")

def main():
    if len(sys.argv)<3:
        print("Usage: python3 explain_signal.py EURUSD M15")
        sys.exit(1)
    pair = sys.argv[1].upper()
    tf   = sys.argv[2].upper()

    candles = load_csv(pair, tf, limit=240)
    last = candles[-1]
    print(f"\n=== Explain {pair} {tf} ===")
    print(f"Last candle: {fmt_ts(last['time'])}  O={last['open']} H={last['high']} L={last['low']} C={last['close']}")

    # You can keep your base_score as configured in your runner/policy.
    out = apply_policy(
        candles=candles,
        dir_hint=None,
        base_score=3.2,   # same base you’ve been using
        pair=pair,
        tf=tf
    )

    # Pretty print
    print("\n--- Decision Snapshot ---")
    score = out.get("score_delta", 0.0)
    veto  = out.get("veto", False)
    tags  = out.get("tags", [])
    notes = out.get("notes", [])
    tel   = out.get("telemetry", {})

    print(f"Score delta:  {score}")
    print(f"Veto:         {veto}")
    print(f"Tags:         {', '.join(tags) if tags else '-'}")
    print(f"Notes:        {', '.join(notes) if notes else '-'}")
    if tel:
        print("\n--- Telemetry ---")
        # We expect your policy_hook to include items like ADX, MACD diff, RSI regime, HTF alignment, etc.
        for k,v in tel.items():
            print(f"{k:>16}: {v}")

    # Decision interpretation (matches your strong mode mentality)
    CONF_MIN = float(os.environ.get("CONF_MIN", "3.0"))
    STRONG_SEND_THRESHOLD = float(os.environ.get("STRONG_SEND_THRESHOLD", "6"))
    decision = "NO SEND"
    reason   = []
    if veto:
        reason.append("VETO active (risk/filters blocked)")
    if score < CONF_MIN:
        reason.append(f"Score {score} < CONF_MIN {CONF_MIN}")
    elif score < STRONG_SEND_THRESHOLD:
        reason.append(f"Score {score} < STRONG threshold {STRONG_SEND_THRESHOLD}")
    else:
        decision = "SEND-OK (meets strong threshold)"

    print("\n--- Decision ---")
    print(f"Result:  {decision}")
    if reason:
        print("Because: " + " | ".join(reason))

    print("\nTip: if this looks too strict, check ADX/RSI/HTF in telemetry. A single missing gate keeps Score low even in a bullish push.\n")

if __name__ == "__main__":
    main()
