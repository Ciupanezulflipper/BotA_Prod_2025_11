#!/usr/bin/env python3
import sys, os, csv, math, argparse
from collections import deque
DATA_DIR = os.path.expanduser("~/bot-a/data/candles")

def read_ohlc(path, limit=600):
    rows=[]
    with open(path, "r") as f:
        for r in csv.reader(f):
            if len(r)<5: continue
            # ts, open, high, low, close
            try:
                rows.append((r[0], float(r[1]), float(r[2]), float(r[3]), float(r[4])))
            except: pass
    return rows[-limit:]

def ema(series, period):
    if not series or period<=1: return series[:]
    k = 2.0/(period+1.0)
    out=[]
    e = None
    for x in series:
        e = x if e is None else (x - e)*k + e
        out.append(e)
    return out

def rsi(series, period=14):
    if len(series)<period+1: return None
    gains, losses = 0.0, 0.0
    for i in range(1, period+1):
        d = series[i]-series[i-1]
        gains += d if d>0 else 0.0
        losses += -d if d<0 else 0.0
    if losses==0: return 100.0
    rs = (gains/period)/(losses/period) if losses>0 else 1e9
    out=[100.0 - 100.0/(1.0+rs)]
    avg_gain, avg_loss = gains/period, losses/period
    for i in range(period+1, len(series)):
        d = series[i]-series[i-1]
        gain = d if d>0 else 0.0
        loss = -d if d<0 else 0.0
        avg_gain = (avg_gain*(period-1)+gain)/period
        avg_loss = (avg_loss*(period-1)+loss)/period
        rs = (avg_gain/avg_loss) if avg_loss>0 else 1e9
        out.append(100.0 - 100.0/(1.0+rs))
    return out[-1] if out else None

def true_range(h, l, cprev):
    return max(h-l, abs(h-cprev), abs(l-cprev))

def adx(high, low, close, period=14):
    n = len(close)
    if n<period+2: return None
    tr_list=[]; plus_dm=[]; minus_dm=[]
    for i in range(1, n):
        up = high[i]-high[i-1]
        dn = low[i-1]-low[i]
        plus_dm.append(up if (up>dn and up>0) else 0.0)
        minus_dm.append(dn if (dn>up and dn>0) else 0.0)
        tr_list.append(true_range(high[i], low[i], close[i-1]))
    # Smooth with Wilder
    def wilder(vals, p):
        out=[]
        s=sum(vals[:p])
        out.append(s)
        for i in range(p, len(vals)):
            s = s - (s/p) + vals[i]
            out.append(s)
        return out
    tr_s = wilder(tr_list, period)
    pdm_s = wilder(plus_dm, period)
    mdm_s = wilder(minus_dm, period)
    # Align
    idx = len(tr_s)-1
    if idx<0: return None
    tr = tr_s[idx]/period
    pdi = (pdm_s[idx]/period)/tr*100.0 if tr>0 else 0.0
    mdi = (mdm_s[idx]/period)/tr*100.0 if tr>0 else 0.0
    dx = abs(pdi-mdi)/(pdi+mdi)*100.0 if (pdi+mdi)>0 else 0.0
    # ADX itself is Wilder on DX; approximate with simple for last slice
    # (good enough for gating)
    return dx  # using DX as momentum proxy; consistent & simple

def macd_diff(close, fast=12, slow=26, signal=9):
    if len(close)<slow+signal+1: return None
    ema_fast = ema(close, fast)
    ema_slow = ema(close, slow)
    macd_line = [a-b for a,b in zip(ema_fast[-len(ema_slow):], ema_slow)]
    sig = ema(macd_line, signal)
    # align last values
    d = macd_line[-1] - sig[-1]
    return d

def sma(series, period):
    if len(series)<period: return None
    return sum(series[-period:])/period

def trend_ok(path, sma_period=20):
    try:
        rows = read_ohlc(path, 200)
        closes=[r[4] for r in rows]
        if len(closes)<sma_period+1: return False
        return closes[-1] > sma(closes, sma_period)
    except: return False

def score_and_reasons(pair, tf, htf_ok_flag=False):
    pfx = f"{pair}_{tf}"
    path = os.path.join(DATA_DIR, f"{pfx}.csv")
    rows = read_ohlc(path, 600)
    if not rows:
        return 0.0, [], {"error": f"No candles at {path}"}

    ts, opens, highs, lows, closes = zip(*rows)
    closes=list(closes); highs=list(highs); lows=list(lows)

    last_rsi = rsi(closes, 14)
    last_adx = adx(highs, lows, closes, 14)
    last_macd = macd_diff(closes, 12, 26, 9)

    # HTF (H1 & H4) alignment using simple SMA20 filter
    h1 = trend_ok(os.path.join(DATA_DIR, f"{pair}_H1.csv"))
    h4 = trend_ok(os.path.join(DATA_DIR, f"{pair}_H4.csv"))
    htf_align = (h1 and h4)

    score = 0.0; reasons = []
    # Gates & partial scores
    # MACD
    if last_macd is None:
        reasons.append(("macd", 0.0, "no-data"))
    elif last_macd > 0:
        score += 0.6
        reasons.append(("macd", 0.6, f"diff {last_macd:.6f} > 0"))
    else:
        reasons.append(("macd", 0.0, f"diff {last_macd:.6f} ≤ 0"))

    # RSI
    if last_rsi is None:
        reasons.append(("rsi", 0.0, "no-data"))
    elif last_rsi >= 60:
        score += 0.6
        reasons.append(("rsi", 0.6, f"RSI {last_rsi:.2f} ≥ 60"))
    else:
        reasons.append(("rsi", 0.0, f"RSI {last_rsi:.2f} < 60"))

    # ADX (two-tier)
    if last_adx is None:
        reasons.append(("adx", 0.0, "no-data"))
    else:
        add = 0.0
        if last_adx >= 18: add += 0.6
        if last_adx >= 22: add += 0.4
        score += add
        reasons.append(("adx", add, f"DX {last_adx:.2f} (≥18 +0.6, ≥22 +0.4)"))

    # HTF
    if htf_ok_flag or htf_align:
        score += 0.6
        reasons.append(("htf", 0.6, f"align={htf_align or htf_ok_flag}"))
    else:
        reasons.append(("htf", 0.0, f"align={htf_align}"))

    telem = {
        "last_macd_diff": None if last_macd is None else float(last_macd),
        "last_rsi": None if last_rsi is None else float(last_rsi),
        "last_adx": None if last_adx is None else float(last_adx),
        "h1_trend_up": h1, "h4_trend_up": h4
    }
    return score, reasons, telem

def main():
    ap = argparse.ArgumentParser(description="Explain confluence decision, with reasons")
    ap.add_argument("pair", help="e.g., EURUSD")
    ap.add_argument("tf", help="e.g., M15")
    ap.add_argument("--conf-min", type=float, default=float(os.environ.get("CONF_MIN", "3.0")))
    ap.add_argument("--htf-ok", action="store_true", help="Force-add HTF align bonus")
    args = ap.parse_args()

    pair = args.pair.upper()
    tf = args.tf.upper()

    score, reasons, telem = score_and_reasons(pair, tf, args.htf_ok)

    print(f"== Explain {pair} {tf} ==")
    print(f"Score: {score:.2f} | Send: {'True' if score>=args.conf_min else 'False'} | Conf_Min: {args.conf_min}")
    print("--- Components (additive) ---")
    for k, add, note in reasons:
        print(f"{k:>6}: {add:.2f}  • {note}")
    print("\n--- Telemetry ---")
    for k,v in telem.items():
        print(f"{k:>15}: {v}")
    print("\nTip: Lower CONF_MIN for testing with:")
    print("  nohup env CONF_MIN=1.8 python3 runner_confluence.py --pair EURUSD --tf M15 --force --dry-run=false >> ~/bot-a/logs/runner.log 2>&1 &")

if __name__ == "__main__":
    main()
