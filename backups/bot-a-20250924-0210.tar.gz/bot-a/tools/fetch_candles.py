#!/usr/bin/env python3
import os, sys, csv, json, urllib.request, urllib.parse, time
OUTDIR = os.path.expanduser("~/bot-a/data/candles")
os.makedirs(OUTDIR, exist_ok=True)

API_KEY = os.environ.get("TWELVE_DATA_API_KEY", "")
if not API_KEY:
    print("[twelvedata] ERROR: missing TWELVE_DATA_API_KEY in env", file=sys.stderr)
    sys.exit(2)

# EURUSD only (symbol format for TwelveData)
SYMBOL = "EUR/USD"
TF_MAP = {"M5":"5min","M15":"15min","H1":"1h","H4":"4h","D1":"1day"}

def twd_series(interval, limit):
    qs = {
        "symbol": SYMBOL,
        "interval": interval,
        "outputsize": str(limit),
        "format": "JSON",
        "apikey": API_KEY,
        "order": "ASC"  # time ascending
    }
    url = "https://api.twelvedata.com/time_series?" + urllib.parse.urlencode(qs)
    with urllib.request.urlopen(url, timeout=20) as r:
        j = json.loads(r.read().decode())
    if "values" not in j:
        raise RuntimeError(f"twelvedata bad response: {j}")
    # fields: datetime, open, high, low, close, volume
    rows = []
    for v in j["values"]:
        # unify to: time,open,high,low,close
        rows.append([v["datetime"], v["open"], v["high"], v["low"], v["close"]])
    return rows

def write_csv(rows, pair, tf):
    path = os.path.join(OUTDIR, f"{pair}_{tf}.csv")
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["time","open","high","low","close"])
        w.writerows(rows)
    print(f"Saved {len(rows)} candles to {path} via twelvedata")

def main():
    # args: --pair EURUSD --tf M15 --limit 300
    args = sys.argv[1:]
    try:
        pair = args[args.index("--pair")+1]
        tf   = args[args.index("--tf")+1]
        limit= int(args[args.index("--limit")+1])
    except Exception:
        print("usage: fetch_candles.py --pair EURUSD --tf {M5|M15|H1|H4|D1} --limit N")
        sys.exit(2)

    if pair.upper() != "EURUSD":
        print("This minimal fetcher only supports EURUSD right now.")
        sys.exit(2)

    if tf not in TF_MAP:
        print(f"Unsupported TF {tf}. Use one of: {list(TF_MAP)}")
        sys.exit(2)

    interval = TF_MAP[tf]
    rows = twd_series(interval, limit)
    write_csv(rows, "EURUSD", tf)

if __name__ == "__main__":
    main()
