import os, sys
BOT_ROOT = os.path.expanduser("~/BotA")
if BOT_ROOT not in sys.path:
    sys.path.insert(0, BOT_ROOT)
import tools.indicators_patch
#!/usr/bin/env python3
from __future__ import annotations

import os, sys, time, json
from typing import Any, Dict, List
from dataclasses import dataclass
from argparse import ArgumentParser
from datetime import datetime, timezone
from urllib.request import urlopen, Request
from urllib.parse import urlencode

# Local modules
from .indicators_ext import compute_confluence
from .scoring_v2 import EnhancedScorer
from .signal_card import build_card

def _log(msg: str) -> None:
    print(f"[{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')}Z] runner: {msg}", flush=True)

def _pair_display(pair: str) -> str:
    p = pair.strip().upper()
    if len(p) == 6 and p.isalpha():
        return f"{p[:3]}/{p[3:]}"
    return p

def _risks(md: Dict[str, Any]) -> List[str]:
    risks: List[str] = []
    # examples: add more when you wire live spread/news:
    # if md.get("mid_candle"): risks.append("mid-candle")
    # if md.get("news"): risks.append("macro event")
    return risks or ["normal"]

def send_telegram(token: str, chat_id: str, text: str) -> bool:
    try:
        api = f"https://api.telegram.org/bot{token}/sendMessage"
        data = urlencode({"chat_id": chat_id, "text": text}).encode()
        req = Request(api, data=data, headers={"Content-Type": "application/x-www-form-urlencoded"})
        with urlopen(req, timeout=12) as r:
            j = json.loads(r.read().decode())
        return bool(j.get("ok"))
    except Exception as e:
        _log(f"Telegram send failed: {e}")
        return False

def main() -> None:
    ap = ArgumentParser()
    ap.add_argument("--pair", required=True)
    ap.add_argument("--tf", required=True)              # e.g. M15 / H1 / D1
    ap.add_argument("--force", action="store_true")     # reserved
    ap.add_argument("--dry-run", default="false")       # true/false
    args = ap.parse_args()

    pair = args.pair.strip().upper()
    tf   = args.tf.strip().upper()
    dry  = str(args.dry_run).lower() == "true"

    pair_disp = _pair_display(pair)

    # 1) features
    md = compute_confluence(pair, tf)

    # 2) score & decision
    scorer = EnhancedScorer()
    out = scorer.score(md)

    # 3) spread placeholder (if you have live quote, compute pips here)
    spread_pips = None

    # 4) PRD card
    card = build_card(
        symbol=pair_disp, tf=tf, decision=out.action,
        base_score=out.base, bonus_score=out.bonus,
        reasons=out.reasons, risks=_risks(md), spread_pips=spread_pips,
    )

    # 5) print always (so scan script can capture)
    print(card, flush=True)

    # 6) optionally send to Telegram
    if not dry:
        token = os.getenv("TELEGRAM_BOT_TOKEN", "")
        chat  = os.getenv("TELEGRAM_CHAT_ID", "")
        if token and chat:
            ok = send_telegram(token, chat, card)
            _log(f"Telegram: {'ok' if ok else 'failed'}")
        else:
            _log("TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID missing; not sending.")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[FATAL] runner error: {e}", file=sys.stderr)
        sys.exit(1)
