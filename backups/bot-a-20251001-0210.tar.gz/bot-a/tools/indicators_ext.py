#!/usr/bin/env python3
from __future__ import annotations

import os, math, json, time
from dataclasses import dataclass
from typing import Dict, Any, List, Tuple
from urllib.request import urlopen
from urllib.parse import urlencode, quote
import numpy as np
from datetime import datetime, timezone

def _log(msg: str) -> None:
    print(f"{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S,%f')[:-3]} INFO:tools.indicators_ext: {msg}", flush=True)

def _as_float(x, default=0.0) -> float:
    try:
        if isinstance(x, (list, tuple, np.ndarray)): x = x[-1]
        return float(x)
    except Exception:
        return float(default)

def _ema(arr: np.ndarray, span: int) -> np.ndarray:
    k = 2.0 / (span + 1.0)
    out = np.empty_like(arr, dtype=float)
    out[0] = arr[0]
    for i in range(1, len(arr)):
        out[i] = out[i-1] + k * (arr[i] - out[i-1])
    return out

def _rsi(close: np.ndarray, period: int = 14) -> np.ndarray:
    diff = np.diff(close, prepend=close[0])
    gains = np.where(diff > 0, diff, 0.0)
    losses = np.where(diff < 0, -diff, 0.0)
    avg_gain = _ema(gains, period)
    avg_loss = _ema(losses, period)
    rs = np.divide(avg_gain, np.where(avg_loss==0, 1e-9, avg_loss))
    return 100.0 - (100.0 / (1.0 + rs))

def _adx(high: np.ndarray, low: np.ndarray, close: np.ndarray, period: int = 14) -> np.ndarray:
    up = np.diff(high, prepend=high[0])
    dn = -np.diff(low, prepend=low[0])
    plus_dm = np.where((up > dn) & (up > 0), up, 0.0)
    minus_dm = np.where((dn > up) & (dn > 0), dn, 0.0)
    tr = np.maximum(high - low, np.maximum(np.abs(high - np.roll(close, 1)), np.abs(low - np.roll(close, 1))))
    tr[0] = high[0] - low[0]
    atr = _ema(tr, period)
    plus_di = 100.0 * _ema(plus_dm, period) / np.where(atr==0, 1e-9, atr)
    minus_di = 100.0 * _ema(minus_dm, period) / np.where(atr==0, 1e-9, atr)
    dx = 100.0 * np.abs(plus_di - minus_di) / np.where((plus_di + minus_di)==0, 1e-9, (plus_di + minus_di))
    adx = _ema(dx, period)
    return adx

def _macd(close: np.ndarray, fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    ema_fast = _ema(close, fast)
    ema_slow = _ema(close, slow)
    macd = ema_fast - ema_slow
    sig  = _ema(macd, signal)
    hist = macd - sig
    return macd, sig, hist

# ---- timeframe mapping -----------------------------------------------------
def _map_tf(tf: str) -> Tuple[str, str]:
    t = tf.strip().lower()
    td = {"m1":"1min","m5":"5min","m15":"15min","m30":"30min","h1":"1h","h4":"4h","d1":"1day"}.get(t, t)
    av = {"m1":"1min","m5":"5min","m15":"15min","m30":"30min","h1":"60min","d1":"daily"}.get(t, "15min")
    return td, av

# ---- data providers --------------------------------------------------------
def _fetch_twelvedata(symbol: str, tf: str, out: int = 250) -> List[Dict[str, Any]]:
    key = os.getenv("TWELVE_DATA_API_KEY", "")
    if not key: return []
    td_interval, _ = _map_tf(tf)
    url = f"https://api.twelvedata.com/time_series?{urlencode({'symbol': symbol, 'interval': td_interval, 'outputsize': out, 'format':'JSON', 'dp':8, 'apikey': key})}"
    with urlopen(url, timeout=12) as r:
        j = json.load(r)
    if 'values' in j:
        return list(reversed(j['values']))
    return []

def _fetch_alpha(symbol: str, tf: str, out: int = 250) -> List[Dict[str, Any]]:
    key = os.getenv("ALPHA_VANTAGE_API_KEY", "")
    if not key: return []
    _, av_interval = _map_tf(tf)
    from_, to_ = symbol[:3], symbol[-3:]
    if av_interval == "daily":
        url = f"https://www.alphavantage.co/query?function=FX_DAILY&from_symbol={from_}&to_symbol={to_}&outputsize=compact&apikey={key}"
        with urlopen(url, timeout=12) as r: j = json.load(r)
        series = j.get("Time Series FX (Daily)", {})
        rows = [{"datetime": ts, "open": v["1. open"], "high": v["2. high"], "low": v["3. low"], "close": v["4. close"], "volume": "0"} for ts, v in sorted(series.items())]
        return rows[-out:]
    else:
        url = f"https://www.alphavantage.co/query?function=FX_INTRADAY&from_symbol={from_}&to_symbol={to_}&interval={av_interval}&outputsize=compact&apikey={key}"
        with urlopen(url, timeout=12) as r: j = json.load(r)
        series = j.get(f"Time Series FX ({av_interval})", {})
        rows = [{"datetime": ts, "open": v["1. open"], "high": v["2. high"], "low": v["3. low"], "close": v["4. close"], "volume": "0"} for ts, v in sorted(series.items())]
        return rows[-out:]

def _load_ohlc(symbol: str, tf: str) -> Dict[str, np.ndarray]:
    rows = _fetch_twelvedata(symbol, tf) or _fetch_alpha(symbol, tf)
    if not rows:
        raise RuntimeError("No market data from providers.")
    close = np.array([float(r["close"]) for r in rows], dtype=float)
    high  = np.array([float(r["high"])  for r in rows], dtype=float)
    low   = np.array([float(r["low"])   for r in rows], dtype=float)
    openp = np.array([float(r["open"])  for r in rows], dtype=float)
    return {"open": openp, "high": high, "low": low, "close": close}

@dataclass
class Confluence:
    rsi: float
    adx: float
    macd_hist: float
    ema_signal: int
    rsi_dz: float
    reasons: List[str]

def compute_confluence(symbol: str, tf: str) -> Dict[str, Any]:
    ohlc = _load_ohlc(symbol, tf)
    close, high, low = ohlc["close"], ohlc["high"], ohlc["low"]

    rsi_arr = _rsi(close, 14)
    adx_arr = _adx(high, low, close, 14)
    macd, macd_sig, macd_hist = _macd(close)

    ema_fast = _ema(close, 9)
    ema_slow = _ema(close, 21)
    ema_signal = 1 if ema_fast[-1] > ema_slow[-1] else (-1 if ema_fast[-1] < ema_slow[-1] else 0)

    rsi = _as_float(rsi_arr[-1], 50.0)
    adx = _as_float(adx_arr[-1], 15.0)
    macd_h = _as_float(macd_hist[-1], 0.0)
    rsi_dz = abs(rsi - 50.0)

    reasons: List[str] = []
    if ema_signal == 1: reasons.append("EMA9/21 bull")
    if ema_signal == -1: reasons.append("EMA9/21 bear")
    if rsi > 55: reasons.append("RSI>55")
    if rsi < 45: reasons.append("RSI<45")
    if macd_h > 0: reasons.append("MACD+")
    if macd_h < 0: reasons.append("MACD-")
    if adx > 20: reasons.append("ADX>20")

    _log(f"RSI {rsi:.1f} | ADX {adx:.1f} | MACD_hist {macd_h:+.6f} | EMA_sig {ema_signal:+d}")

    return {
        "rsi": rsi,
        "adx": adx,
        "macd": macd_h,
        "ema_signal": int(ema_signal),
        "rsi_dz": rsi_dz,
        "reasons": reasons,
    }
