from __future__ import annotations
import os, json, urllib.request, urllib.parse
from datetime import datetime, timezone

TF_SEC = {"M1":60,"M5":300,"M15":900,"M30":1800,"H1":3600,"H4":14400,"D1":86400}

def _http_json(url: str, headers: dict | None=None, timeout: int=20):
    req = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())

def _now_utc() -> int:
    return int(datetime.now(timezone.utc).timestamp())

def _sym(pair:str):
    base, quote = pair[:3], pair[3:]
    return {
        "slash": f"{base}/{quote}",
        "finnhub": f"OANDA:{base}_{quote}",
        "av_from": base, "av_to": quote,
    }

def fetch_finnhub(pair:str, tf:str, bars:int=200):
    key = os.getenv("FINNHUB_API_KEY")
    if not key: return None
    sec = TF_SEC.get(tf);  to = _now_utc()
    if not sec: return None
    frm = to - (bars+5)*sec
    sym = _sym(pair)["finnhub"]
    url = ("https://finnhub.io/api/v1/forex/candle"
           f"?symbol={urllib.parse.quote(sym)}&resolution={sec}&from={frm}&to={to}&token={key}")
    js = _http_json(url)
    if js.get("s") != "ok": return None
    out=[]
    for t,o,h,l,c,v in zip(js["t"], js["o"], js["h"], js["l"], js["c"], js.get("v",[0]*len(js["t"]))):
        out.append({"t":int(t),"o":float(o),"h":float(h),"l":float(l),"c":float(c),"v":float(v)})
    return out

def fetch_twelvedata(pair:str, tf:str, bars:int=200):
    key = os.getenv("TWELVE_DATA_API_KEY")
    if not key: return None
    m={"M1":"1min","M5":"5min","M15":"15min","M30":"30min","H1":"1h","H4":"4h","D1":"1day"}
    interval = m.get(tf);  sym=_sym(pair)["slash"]
    if not interval: return None
    url = ("https://api.twelvedata.com/time_series"
           f"?symbol={urllib.parse.quote(sym)}&interval={interval}&outputsize={bars}&apikey={key}&format=JSON")
    js = _http_json(url); vals = js.get("values")
    if not vals: return None
    vals = vals[::-1]
    out=[]
    for it in vals:
        dt = datetime.fromisoformat(it["datetime"])
        ts = int(dt.replace(tzinfo=timezone.utc).timestamp())
        out.append({"t":ts,"o":float(it["open"]),"h":float(it["high"]),"l":float(it["low"]),"c":float(it["close"]),"v":float(it.get("volume",0))})
    return out

def fetch_alphavantage(pair:str, tf:str, bars:int=200):
    key = os.getenv("ALPHA_VANTAGE_API_KEY")
    if not key or tf!="D1": return None
    base=_sym(pair)["av_from"]; quote=_sym(pair)["av_to"]
    url = f"https://www.alphavantage.co/query?function=FX_DAILY&from_symbol={base}&to_symbol={quote}&apikey={key}"
    js = _http_json(url); data = js.get("Time Series FX (Daily)")
    if not data: return None
    items = sorted(data.items())[-bars:]
    out=[]
    for k,v in items:
        dt = datetime.fromisoformat(k)
        ts = int(dt.replace(tzinfo=timezone.utc).timestamp())
        out.append({"t":ts,"o":float(v["1. open"]),"h":float(v["2. high"]),"l":float(v["3. low"]),"c":float(v["4. close"]),"v":0.0})
    return out

def get_ohlc(pair:str, tf:str, bars:int=200):
    for fn in (fetch_finnhub, fetch_twelvedata, fetch_alphavantage):
        try:
            data = fn(pair, tf, bars)
            if data and len(data) >= max(50, int(bars*0.6)):
                return data, fn.__name__
        except Exception:
            pass
    return None, None
