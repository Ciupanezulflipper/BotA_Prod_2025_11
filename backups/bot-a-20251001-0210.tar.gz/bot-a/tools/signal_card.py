#!/usr/bin/env python3
from __future__ import annotations
from datetime import datetime, timezone
from typing import Dict, Any, List

def _fmt_ts(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

def build_card(symbol: str, tf: str, decision: str, base_score: float, bonus_score: float,
               reasons: List[str], spread_pips: float | None = None,
               risks: List[str] | None = None, tstamp: datetime | None = None) -> str:
    """
    Output Format (PRD):

    📊 SYMBOL (TF)
    🕒 Signal Time: UTC Timestamp
    📈 Action: ✅ BUY / ❌ SELL / ⏸️ WAIT
    📊 Score: X/16 + Y/6
    🧠 Reason: key indicators
    ⚠️ Risk: items
    📉 Spread: X.X pips
    """
    ts = _fmt_ts(tstamp or datetime.now(timezone.utc))
    act_emoji = {"BUY":"✅","SELL":"❌","WAIT":"⏸️"}.get(decision, "⏸️")
    header = f"📊 {symbol} ({tf})"
    line_time = f"🕒 Signal Time: {ts}"
    line_action = f"📈 Action: {act_emoji} {decision}"
    line_score  = f"📊 Score: {base_score:.0f}/16 + {bonus_score:.0f}/6"
    reason_txt = " + ".join(reasons[:6]) if reasons else "n/a"
    line_reason = f"🧠 Reason: {reason_txt}"
    risk_txt = "normal" if not risks else ", ".join(risks)
    line_risk = f"⚠️ Risk: {risk_txt}"
    spread_txt = f"{spread_pips:.1f} pips" if spread_pips is not None else "n/a"
    line_spread = f"📉 Spread: {spread_txt}"
    return "\n".join([header, line_time, line_action, line_score, line_reason, line_risk, line_spread])
