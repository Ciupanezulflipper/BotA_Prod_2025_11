#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

cd "$HOME/BotA" || exit 1
[ -f .env ] && export $(grep -v ^# .env | xargs) || true
export PYTHONPATH="$HOME/BotA:${PYTHONPATH:-}"

echo "=== SELF CHECK ==="
python3 - << 'PY' || true
import os, json, sys, pkgutil, platform, time
env_keys = ["TELEGRAM_BOT_TOKEN","TELEGRAM_CHAT_ID","TWELVE_DATA_API_KEY","ALPHA_VANTAGE_API_KEY"]
env = {k: (os.getenv(k)[:4]+"…"+os.getenv(k)[-3:] if os.getenv(k) else None) for k in env_keys}
out = {
  "timestamp": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
  "python_version": platform.python_version(),
  "imports": {m: bool(pkgutil.find_loader(m)) for m in [
      "tools.indicators_ext","tools.scoring_v2","tools.signal_card","tools.runner_confluence"
  ]},
  "env": env,
}
print(json.dumps(out, indent=2))
PY

echo
echo "=== PRD CARD SMOKE (DRY RUN) ==="
# Always succeed and print a PRD card (WAIT if providers/runner fail)
PAIR="${PAIR:-EURUSD}" TF="${TF:-M15}" python3 "$HOME/BotA/tools/run_prd_smoke.py" || true
