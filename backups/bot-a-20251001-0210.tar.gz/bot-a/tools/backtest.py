#!/usr/bin/env python3
from __future__ import annotations
import csv, argparse, numpy as np
from typing import List, Dict
from .scoring_v2 import EnhancedScorer

def load_csv(path: str) -> Dict[str, np.ndarray]:
    # Expect columns: time, open, high, low, close
    t,o,h,l,c = [],[],[],[],[]
    with open(path,"r",newline="",encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            o.append(float(row["open"])); h.append(float(row["high"]))
            l.append(float(row["low"]));  c.append(float(row["close"]))
            t.append(row["time"])
    return {"open":np.array(o), "high":np.array(h), "low":np.array(l), "close":np.array(c)}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--symbol", default="EURUSD")
    args = ap.parse_args()

    data = load_csv(args.csv)
    price = float(data["close"][-1])
    scorer = EnhancedScorer()
    base = 0.8  # placeholder
    res = scorer.calculate_enhanced_score(base, {**data, "current_price":price, "rsi":np.zeros_like(data["close"])}, args.symbol, 1)
    print(f"Score sample: {res.final_score:.3f} passed={res.passed}")

if __name__ == "__main__":
    main()
