#!/usr/bin/env python3
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List

@dataclass
class ScoreOut:
    action: str          # "BUY" | "SELL" | "WAIT"
    base: float          # 0..16
    bonus: float         # 0..6
    buy_sum: float       # internal
    sell_sum: float      # internal
    reasons: List[str]

class EnhancedScorer:
    """
    Simple, transparent scoring:
      Base /16:
        + RSI distance from 50 (max 6)
        + ADX strength (max 4)
        + MACD histogram magnitude & sign (max 4)
        + EMA cross alignment (max 2)
      Bonus /6:
        + RSI & MACD agree with EMA direction (max 3)
        + Strong trend (ADX>25) (max 3)
    """
    def score(self, md: Dict[str, Any]) -> ScoreOut:
        rsi  = float(md.get("rsi", 50.0))
        adx  = float(md.get("adx", 15.0))
        macd = float(md.get("macd", 0.0))
        ema  = int(md.get("ema_signal", 0))
        rsi_dz = float(md.get("rsi_dz", abs(rsi-50.0)))
        reasons = list(md.get("reasons", []))

        # --- base
        # RSI: up to 6 points for distance from 50 (cap 25pts => 6)
        rsi_pts = min(rsi_dz / 25.0 * 6.0, 6.0)

        # ADX: 0..4 scaling from 15 to 35
        if adx <= 15: adx_pts = 0.0
        elif adx >= 35: adx_pts = 4.0
        else: adx_pts = (adx - 15.0) / 20.0 * 4.0

        # MACD: 0..4 by |hist| (cap 0.0015)
        macd_mag = abs(macd)
        macd_pts = min(macd_mag / 0.0015 * 4.0, 4.0)

        # EMA cross: 2 if aligned, 0 if flat (ema=0)
        ema_pts = 2.0 if ema != 0 else 0.0

        base = rsi_pts + adx_pts + macd_pts + ema_pts

        # --- direction buckets
        buy_sum  = 0.0
        sell_sum = 0.0
        if ema > 0: buy_sum += 1
        if ema < 0: sell_sum += 1
        if rsi > 50: buy_sum += (rsi_dz/25.0)
        if rsi < 50: sell_sum += (rsi_dz/25.0)
        if macd > 0: buy_sum += min(macd_mag/0.0015, 1.0)
        if macd < 0: sell_sum += min(macd_mag/0.0015, 1.0)

        # --- bonus (agreement + strong trend)
        bonus = 0.0
        agree = 0
        if ema > 0 and rsi > 50: agree += 1
        if ema > 0 and macd > 0: agree += 1
        if ema < 0 and rsi < 50: agree += 1
        if ema < 0 and macd < 0: agree += 1
        bonus += min(agree, 3)  # 0..3

        if adx > 25: bonus += min((adx-25)/10.0 * 3.0, 3.0)  # up to +3

        # --- decision
        if base >= 9 and ((buy_sum - sell_sum) > 0.5):
            action = "BUY"
        elif base >= 9 and ((sell_sum - buy_sum) > 0.5):
            action = "SELL"
        else:
            action = "WAIT"

        # reasons
        if action == "BUY": reasons.insert(0, "Trend up")
        elif action == "SELL": reasons.insert(0, "Trend down")
        else: reasons.insert(0, "No edge")

        return ScoreOut(action=action, base=round(base, 2), bonus=round(bonus, 2),
                        buy_sum=round(buy_sum, 2), sell_sum=round(sell_sum, 2),
                        reasons=reasons)
