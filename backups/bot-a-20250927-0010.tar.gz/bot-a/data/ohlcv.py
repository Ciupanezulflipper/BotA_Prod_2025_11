# Minimal OHLCV fetcher (TwelveData -> AlphaVantage fallback)
# Accepts multiple env var spellings without changing .env
import os, time, requests

def _get_any(*names):
    """Return first non-empty env value among provided names."""
    for n in names:
        v = os.getenv(n, "").strip()
        if v:
            return v
    return None

# Accept both styles without forcing user to rename .env keys
TD = _get_any("TWELVE_DATA_API_KEY", "TWELVEDATA_API_KEY")
AV = _get_any("ALPHA_VANTAGE_API_KEY", "ALPHAVANTAGE_API_KEY")

def _http_json(url, params=None, timeout=8):
    r = requests.get(url, params=params or {}, timeout=timeout)
    r.raise_for_status()
    return r.json()

def _normalize_symbol(sym: str) -> str:
    # Prefer "EUR/USD" style for TwelveData; AV needs from/to split later
    s = sym.strip().upper().replace(" ", "")
    if "/" not in s and len(s) == 6:  # EURUSD -> EUR/USD
        s = f"{s[:3]}/{s[3:]}"
    return s

def fetch(symbol="EURUSD", tf="5min", limit=200):
    """
    Returns list of candles [{t,o,h,l,c,v}], oldest->newest.
    tf in {"1min","5min","15min","60min"}.
    """
    symbol = _normalize_symbol(symbol)
    out = []

    # --- TwelveData first (if key present) ---
    if TD:
        tf_map = {"1min":"1min", "5min":"5min", "15min":"15min", "60min":"1h"}
        interval = tf_map.get(tf, "5min")
        try:
            js = _http_json(
                "https://api.twelvedata.com/time_series",
                {
                    "symbol": symbol,            # e.g. EUR/USD
                    "interval": interval,
                    "apikey": TD,
                    "outputsize": str(min(limit, 500)),
                },
                timeout=8,
            )
            data = js.get("values") or []
            rows = []
            for it in reversed(data):  # oldest -> newest
                rows.append({
                    "t": it.get("datetime"),
                    "o": float(it["open"]),
                    "h": float(it["high"]),
                    "l": float(it["low"]),
                    "c": float(it["close"]),
                    "v": float(it.get("volume", 0) or 0.0),
                })
            if rows:
                return rows[-limit:]  # cap to limit
        except Exception:
            pass  # fall through to AV

    # --- AlphaVantage fallback (if key present) ---
    if AV:
        try:
            frm, to = symbol.split("/") if "/" in symbol else (symbol[:3], symbol[3:])
            intr = {"1min":"1min", "5min":"5min", "15min":"15min", "60min":"60min"}.get(tf, "5min")
            js = _http_json(
                "https://www.alphavantage.co/query",
                {
                    "function": "FX_INTRADAY",
                    "from_symbol": frm,
                    "to_symbol": to,
                    "interval": intr,
                    "apikey": AV,
                    "outputsize": "compact",
                },
                timeout=8,
            )
            # AV returns "Time Series FX (5min)" etc.
            key = next((k for k in js.keys() if k.startswith("Time Series")), None)
            series = js.get(key, {})
            # items are newest->oldest; we want oldest->newest
            rows = []
            for ts, it in sorted(series.items()):
                rows.append({
                    "t": ts,
                    "o": float(it["1. open"]),
                    "h": float(it["2. high"]),
                    "l": float(it["3. low"]),
                    "c": float(it["4. close"]),
                    "v": 0.0,  # AV FX endpoint has no volume
                })
            if rows:
                return rows[-limit:]
        except Exception:
            pass

    # No data from either provider
    return out
