#!/bin/bash
# rotate_logs.sh — prune old logs & cap size

set -euo pipefail
LOGDIR="$HOME/bot-a/logs"
mkdir -p "$LOGDIR"

# Delete logs older than 7 days
find "$LOGDIR" -type f -name "*.log" -mtime +7 -print -delete

# Truncate any log larger than ~1MB (keep last 2000 lines)
for f in "$LOGDIR"/*.log; do
  [ -f "$f" ] || continue
  if [ "$(wc -c <"$f")" -gt 1048576 ]; then
    tail -n 2000 "$f" > "$f.tmp" && mv "$f.tmp" "$f"
  fi
done
