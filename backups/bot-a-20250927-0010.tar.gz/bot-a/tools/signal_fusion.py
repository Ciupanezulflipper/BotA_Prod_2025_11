#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Fuse recent NEWS trades with (latest) TECH state and send 1 Telegram card.
- Reads recent rows from logs/tilted-YYYYMMDD.csv (output of news_signals.py)
- (Optional) reads latest tech bucket/score; falls back to HOLD/0
- Applies a simple cooldown/dup de-dupe gate (fusion_state.DecisionGate)
- Appends to logs/fused-YYYYMMDD.csv
- Sends a single Telegram card summarizing all trades in window

Fixes:
- Make all datetimes **offset-aware UTC** to avoid "offset-naive vs offset-aware"
  comparisons on Termux/Python.
"""

from __future__ import annotations

import os
import csv
import argparse
import datetime as dt
from pathlib import Path
from typing import List, Dict, Tuple

# local helpers (both exist in your repo)
from fusion_state import DecisionGate
from telegramsender import send_telegram_message  # thin wrapper using requests

HOME = Path(os.path.expanduser("~"))
LOG_DIR = HOME / "bot-a" / "logs"
DAILY_DIR = LOG_DIR / "daily"


def _utcnow() -> dt.datetime:
    """Aware UTC 'now'."""
    return dt.datetime.now(dt.timezone.utc)


def _parse_iso_utc(s: str) -> dt.datetime | None:
    """
    Parse ISO timestamp. If it lacks tzinfo, force UTC.
    Returns None on failure.
    """
    try:
        t = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
        if t.tzinfo is None:
            t = t.replace(tzinfo=dt.timezone.utc)
        return t.astimezone(dt.timezone.utc)
    except Exception:
        return None


def _today_iso() -> str:
    return _utcnow().strftime("%Y%m%d")


def _yesterday_iso() -> str:
    return (_utcnow() - dt.timedelta(days=1)).strftime("%Y%m%d")


def _tilted_csv_paths() -> List[Path]:
    """Return today's then yesterday's tilted CSV paths (if they exist)."""
    paths = [
        LOG_DIR / f"tilted-{_today_iso()}.csv",
        LOG_DIR / f"tilted-{_yesterday_iso()}.csv",
    ]
    return [p for p in paths if p.exists()]


def latest_news_trades(since_min: int) -> List[Dict[str, str]]:
    """
    Read recent trades from tilted-YYYYMMDD.csv within 'since_min' minutes.
    Expected columns: time_utc (or time), symbol, decision, news_score, why
    Unknown/missing fields are handled safely.
    """
    cutoff = _utcnow() - dt.timedelta(minutes=since_min)
    out: List[Dict[str, str]] = []

    for path in _tilted_csv_paths():
        try:
            with path.open("r", newline="") as f:
                r = csv.DictReader(f)
                for row in r:
                    # time column name variations
                    t_str = row.get("time_utc") or row.get("time") or ""
                    t = _parse_iso_utc(t_str)
                    if t is None:
                        continue
                    if t < cutoff:
                        continue

                    decision = (row.get("decision") or "").upper()
                    if decision not in ("BUY", "SELL"):
                        # ignore HOLD / empty for the fusion stage
                        continue

                    # Normalize fields we use later
                    row["time_utc"] = t.isoformat().replace("+00:00", "Z")
                    row["symbol"] = (row.get("symbol") or "").upper()
                    row["decision"] = decision
                    try:
                        row["news_score"] = str(int(float(row.get("news_score", "0"))))
                    except Exception:
                        row["news_score"] = "0"
                    row["why"] = row.get("why") or ""

                    out.append(row)
        except Exception:
            # Ignore bad/locked files and continue
            continue

    return out


def latest_tech_bucket(day: str, symbol: str) -> Tuple[str, int]:
    """
    Try to read the most recent tech bucket/score from your daily summary.
    Falls back to ("HOLD", 0) if not found or on error.
    """
    # Typical file: logs/daily/summary-YYYYMMDD.csv
    p = DAILY_DIR / f"summary-{day}.csv"
    if not p.exists():
        # try yesterday as a fallback
        p = DAILY_DIR / f"summary-{_yesterday_iso()}.csv"
        if not p.exists():
            return ("HOLD", 0)

    try:
        with p.open("r", newline="") as f:
            r = csv.DictReader(f)
            for row in r:
                if (row.get("symbol") or row.get("Symbol") or "").upper() == symbol:
                    # common column spellings
                    bucket = (row.get("bucket") or row.get("tech_bucket") or "HOLD").upper()
                    try:
                        score = int(float(row.get("score") or row.get("tech_score") or "0"))
                    except Exception:
                        score = 0
                    return (bucket, score)
    except Exception:
        pass

    return ("HOLD", 0)


def append_fused(day: str, symbol: str, decision: str, tech_score: int,
                 news_score: int, why: str, msg: str) -> None:
    """Append one fused row to logs/fused-YYYYMMDD.csv (create header if new)."""
    fused_path = LOG_DIR / f"fused-{day}.csv"
    new_file = not fused_path.exists()

    with fused_path.open("a", newline="") as f:
        w = csv.writer(f)
        if new_file:
            w.writerow(["day", "symbol", "decision", "tech_score", "news_score", "why", "msg"])
        w.writerow([day, symbol, decision, tech_score, news_score, why, msg])


def compose_card(symbol: str, decision: str, news_score: int, why: str,
                 tech_bucket: str, tech_score: int) -> str:
    """
    Build nice Telegram text for one symbol.
    """
    header = f"🧩 Confluence (UTC {_utcnow().strftime('%H:%MZ')})"
    body = (
        f"• {symbol}: {decision} (score {news_score:.0f})\n"
        f"  TECH: {tech_bucket} ({tech_score})  •  NEWS: {news_score}\n"
        f"  Why: {why or 'n/a'}"
    )
    return f"{header}\n{body}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--since-min", type=int, default=120, help="Lookback window in minutes")
    ap.add_argument("--send", action="store_true", help="Send Telegram")
    ap.add_argument("--dry", action="store_true", help="No writes / no Telegram")
    args = ap.parse_args()

    trades = latest_news_trades(args.since_min)
    if not trades:
        print("No recent news trades to fuse.")
        return 0

    gate = DecisionGate()
    day = _utcnow().strftime("%Y%m%d")

    sent = 0
    for r in trades:
        symbol = (r.get("symbol") or "").upper()
        decision = (r.get("decision") or "WAIT").upper()
        try:
            news_score = int(float(r.get("news_score", "0")))
        except Exception:
            news_score = 0
        why = r.get("why") or ""

        tech_bucket, tech_score = latest_tech_bucket(day, symbol)
        msg = compose_card(symbol, decision, news_score, why, tech_bucket, tech_score)

        sig = gate.signature(symbol, decision, tech_bucket, str(news_score))
        if not gate.should_send(symbol, sig):
            print(f"SKIP {symbol}: suppressed by cooldown/de-dupe.")
            continue

        if not args.dry:
            append_fused(day, symbol, decision, tech_score, news_score, why, msg)
            print("APPEND -> fused CSV")

        if args.send and not args.dry:
            ok = send_telegram_message(msg)
            print("Telegram card sent." if ok else "Telegram send failed.")
            sent += 1

    if sent == 0:
        print("Nothing sent.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
