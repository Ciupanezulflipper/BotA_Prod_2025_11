#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Unified signal runner:
- Rotates data providers (via tools.data_rotator.get_ohlc_rotating)
- Computes indicators (EMA/RSI/MACD)
- Scores & decides (BUY/SELL/HOLD)
- Logs to ~/bot-a/logs/auto_final.log
- Optional Telegram push with --send
"""

import os, sys, json, argparse, datetime as dt
import pandas as pd
from pathlib import Path

# ---- Logging setup ---------------------------------------------------------
LOG_DIR = Path(os.environ.get("HOME", "")) / "bot-a" / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "auto_final.log"

def log(msg):
    utc = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    line = f"LOG UTC {utc} | {msg}"
    print(line)
    try:
        with LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

# ---- Import the rotator (already created earlier) --------------------------
try:
    from tools.data_rotator import get_ohlc_rotating
except Exception as e:
    log(f"FATAL: cannot import data_rotator: {e}")
    sys.exit(2)

# ---- Small TA helpers (no external deps) -----------------------------------
def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()

def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    up = (delta.clip(lower=0)).rolling(period).mean()
    down = (-delta.clip(upper=0)).rolling(period).mean()
    rs = up / (down.replace(0, pd.NA))
    out = 100 - (100 / (1 + rs))
    return out.fillna(method="bfill")

def macd(series: pd.Series, fast=12, slow=26, signal=9):
    ema_fast = ema(series, fast)
    ema_slow = ema(series, slow)
    macd_line = ema_fast - ema_slow
    sig = ema(macd_line, signal)
    hist = macd_line - sig
    return macd_line, sig, hist

# ---- Scoring / decision ----------------------------------------------------
def score_frame(df: pd.DataFrame) -> dict:
    """
    Expects columns: ['open','high','low','close']
    Returns dict with all indicators + a vote score.
    """
    close = df["close"].astype(float)

    out = {}
    out["close"] = float(close.iloc[-1])

    out["ema9"]  = float(ema(close, 9).iloc[-1])
    out["ema21"] = float(ema(close, 21).iloc[-1])
    out["ema50"] = float(ema(close, 50).iloc[-1])

    out["rsi14"] = float(rsi(close, 14).iloc[-1])
    out["rsi21"] = float(rsi(close, 21).iloc[-1])

    m_line, m_sig, m_hist = macd(close, 12, 26, 9)
    out["macd"]     = float(m_line.iloc[-1])
    out["macd_sig"] = float(m_sig.iloc[-1])
    out["macd_hist"]= float(m_hist.iloc[-1])

    # Votes: simple, robust, same spirit as earlier tests
    votes = 0
    votes += 1 if out["close"] > out["ema9"]  else 0
    votes += 1 if out["close"] > out["ema21"] else 0
    votes += 1 if out["close"] > out["ema50"] else 0
    votes += 1 if out["rsi14"]  > 50         else 0
    votes += 1 if out["macd_hist"] > 0       else 0

    out["vote"] = votes
    return out

def decide(v4h: int, v1d: int) -> str:
    """
    Simple cross-timeframe rule:
      - Strong BUY: both >=4
      - Strong SELL: both <=1
      - Otherwise BUY if 1d >=4, SELL if 1d <=1, else HOLD
    """
    if v4h >= 4 and v1d >= 4:
        return "BUY"
    if v4h <= 1 and v1d <= 1:
        return "SELL"
    if v1d >= 4:
        return "BUY"
    if v1d <= 1:
        return "SELL"
    return "HOLD"

# ---- Telegram (optional) ---------------------------------------------------
def send_telegram(text: str) -> None:
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat  = os.environ.get("TELEGRAM_CHAT_ID") or os.environ.get("TELEGRAM_CHAT")
    if not token or not chat:
        log("Telegram skipped (missing TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID).")
        return
    try:
        import urllib.parse, urllib.request
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        payload = urllib.parse.urlencode({"chat_id": chat, "text": text}).encode()
        req = urllib.request.Request(url, data=payload, method="POST")
        with urllib.request.urlopen(req, timeout=10) as r:
            _ = r.read()
        log("Telegram sent.")
    except Exception as e:
        log(f"Telegram send failed: {e}")

# ---- Limits from env (no file edits) ---------------------------------------
def env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, "").strip() or default)
    except Exception:
        return default

H1_LIMIT = env_int("H1_LIMIT", 120)
H4_LIMIT = env_int("H4_LIMIT", 50)
D1_LIMIT = env_int("D1_LIMIT", 100)

# ---- Main ------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", required=True, help="e.g. EURUSD or XAUUSD")
    parser.add_argument("--send", action="store_true", help="Send to Telegram if decision != HOLD")
    parser.add_argument("--dry",  action="store_true", help="No Telegram send; print only")
    args = parser.parse_args()

    symbol = args.symbol.upper()

    # 1) Fetch frames with provider rotation
    frames = {}
    provs  = {}

    # 1h (some providers may block intraday for gold; rotator will skip/choose next)
    try:
        df1h, p1h = get_ohlc_rotating(symbol, "1h", limit=H1_LIMIT)
        frames["1h"] = df1h
        provs["1h"]  = p1h
        log(f"{symbol} 1h via {p1h} rows={len(df1h)} last={df1h.index[-1]}")
    except Exception as e:
        log(f"FAIL {symbol} 1h -> {e}")

    # 4h
    try:
        df4h, p4h = get_ohlc_rotating(symbol, "4h", limit=H4_LIMIT)
        frames["4h"] = df4h
        provs["4h"]  = p4h
        log(f"{symbol} 4h via {p4h} rows={len(df4h)} last={df4h.index[-1]}")
    except Exception as e:
        log(f"FAIL {symbol} 4h -> {e}")

    # 1d
    try:
        d1, p1d = get_ohlc_rotating(symbol, "1d", limit=D1_LIMIT)
        frames["1d"] = d1
        provs["1d"]  = p1d
        log(f"{symbol} 1d via {p1d} rows={len(d1)} last={d1.index[-1]}")
    except Exception as e:
        log(f"FAIL {symbol} 1d -> {e}")

    if not frames:
        log(f"FATAL: no data frames available for {symbol}.")
        sys.exit(3)

    # 2) Indicators & votes
    pack = {}
    if "1h" in frames:
        pack["1h"] = score_frame(frames["1h"])
        pack["1h"]["provider"] = provs.get("1h")
    if "4h" in frames:
        pack["4h"] = score_frame(frames["4h"])
        pack["4h"]["provider"] = provs.get("4h")
    if "1d" in frames:
        pack["1d"] = score_frame(frames["1d"])
        pack["1d"]["provider"] = provs.get("1d")

    # 3) Decision (prefer 4h+1d; fallbacks if missing)
    v4h = pack.get("4h", {}).get("vote", 0)
    v1d = pack.get("1d", {}).get("vote", 0)
    decision = decide(v4h, v1d)

    # 4) Compose preview payload
    preview = {
        "symbol": symbol,
        "decision": decision,
        "tech": 10.0,   # synthetic confidence scale 0-10
        "entry": pack.get("1h", pack.get("4h", pack.get("1d", {}))).get("close"),
        "tp": None,
        "sl": None,
        "providers": provs,
        "votes": {k: pack[k]["vote"] for k in pack}
    }

    time_now = dt.datetime.now(dt.timezone.utc).strftime("UTC %H:%M")
    log(f"*preview* {time_now} payload: {json.dumps(preview, default=str)}")

    # 5) Output brief to console
    def row(k):
        if k not in pack: return f"{k}: —"
        p = pack[k]
        return (f"{k} | close {p['close']:.5f} | ema9={p['ema9']:.5f} "
                f"ema21={p['ema21']:.5f} rsi14={p['rsi14']:.1f} "
                f"macd_hist={p['macd_hist']:.5f} | vote={p['vote']} "
                f"| provider={p.get('provider')}")
    print("\n=== TECH PACK ===")
    print(row("1h"))
    print(row("4h"))
    print(row("1d"))
    print(f"\n{symbol} | {time_now} | {decision}")

    # 6) Telegram (only if requested and not dry)
    if args.send and not args.dry and decision != "HOLD":
        msg = (f"{symbol} {time_now}\n"
               f"Decision: {decision}\n"
               f"Votes: 4h={v4h} 1d={v1d}\n"
               f"Providers: {provs}\n"
               f"Entry≈ {preview['entry']}")
        send_telegram(msg)

if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as ex:
        log(f"FATAL in runner: {ex}")
        raise
