#!/usr/bin/env python3
# tools/telegramalert.py
# Minimal Telegram sender for Bot-A with safe fallbacks (plain text by default).

import os, json, time, urllib.request, urllib.parse, urllib.error
from typing import Optional, Dict, Any

API_ROOT   = os.environ.get("BOT_A_TG_API_ROOT", "https://api.telegram.org").strip().rstrip("/")
BOT_TOKEN  = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
CHAT_ID    = os.environ.get("TELEGRAM_CHAT_ID", "").strip()

# Parse mode: "Markdown" / "MarkdownV2" or "" (plain). Default is plain to avoid 400s.
PARSE_MODE = os.environ.get("BOT_A_TG_PARSE", "").strip()

# Network knobs
TIMEOUT_S     = float(os.environ.get("BOT_A_TG_TIMEOUT", "9").strip() or "9")
RETRY_COUNT   = int(os.environ.get("BOT_A_TG_RETRIES", "2").strip() or "2")
RETRY_WAIT_S  = float(os.environ.get("BOT_A_TG_RETRY_WAIT", "0.8").strip() or "0.8")

# Telegram hard limit ~4096 chars; keep a little headroom
MAX_LEN = 4090

def _post(method: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Low-level POST to Telegram. Raises on transport errors.
    Returns parsed JSON (may be {} if parse fails).
    """
    url = f"{API_ROOT}/bot{BOT_TOKEN}/{method}"
    data = urllib.parse.urlencode(payload).encode("utf-8")
    req  = urllib.request.Request(url, data=data, headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=TIMEOUT_S) as resp:
        body = resp.read().decode("utf-8", errors="replace")
    try:
        return json.loads(body)
    except Exception:
        return {}

def _safe_send_text(text: str) -> bool:
    """
    Safe plain-text sender with retry and truncation.
    Returns True if Telegram accepted it; False if only printed.
    """
    if len(text) > MAX_LEN:
        text = text[:MAX_LEN-20] + "\n…(truncated)"

    payload: Dict[str, Any] = {"chat_id": CHAT_ID, "text": text}
    # Only add parse_mode if explicitly requested (default is plain → fewer 400s)
    if PARSE_MODE and PARSE_MODE.lower().startswith("markdown"):
        payload["parse_mode"] = PARSE_MODE
    payload["disable_web_page_preview"] = True

    last_err: Optional[str] = None
    for _ in range(RETRY_COUNT + 1):
        try:
            res = _post("sendMessage", payload)
            if res.get("ok", False):
                return True
            # Not ok → capture reason if present and break (usually 400 formatting)
            last_err = res.get("description") or str(res)
            break
        except Exception as e:
            last_err = f"transport_error: {e}"
            time.sleep(RETRY_WAIT_S)

    # Fallback to stdout so the signal is never lost
    print(text)
    if last_err:
        print(f"[telegramalert] send failed: {last_err}")
    return False

# ---------------------- Public API ----------------------

def send_text(text: str) -> bool:
    """Send plain text (or Markdown if BOT_A_TG_PARSE is set)."""
    if not BOT_TOKEN or not CHAT_ID:
        print(text)
        print("[telegramalert] creds missing → printed")
        return False
    try:
        return _safe_send_text(text)
    except Exception as e:
        print(text)
        print(f"[telegramalert] exception → printed: {e}")
        return False

def send_card(payload: Dict[str, Any]) -> bool:
    """
    Send a composed card using tools.card_templates.compose_card().
    Falls back to a minimal plain text if compose fails.
    """
    if not BOT_TOKEN or not CHAT_ID:
        # still print something
        minimal = f"{payload.get('symbol','?')} {payload.get('decision','?')} | conf {payload.get('confidence','?')} | {payload.get('timeframe','?')}"
        print(minimal)
        print("[telegramalert] creds missing → printed")
        return False

    try:
        from tools.card_templates import compose_card
        card = compose_card(**payload)
        return send_text(card)  # uses plain or Markdown based on env
    except Exception as e:
        # Compose failed → send minimal info so the run isn’t lost
        minimal = (
            f"*{payload.get('symbol','?')} Signal*\n"
            f"Direction: {payload.get('decision','?')}\n"
            f"Confidence: {payload.get('confidence','?')}\n"
            f"Entry: {payload.get('entry','?')}  TP: {payload.get('tp','?')}  SL: {payload.get('sl','?')}\n"
            f"Why: {payload.get('why','?')}\n"
            f"(compose error: {e})"
        )
        return send_text(minimal)

def get_me() -> Optional[Dict[str, Any]]:
    """Return getMe() result or None on error."""
    if not BOT_TOKEN:
        return None
    try:
        return _post("getMe", {})
    except Exception:
        return None

# Optional: quick CLI for manual tests
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        msg = " ".join(sys.argv[1:])
    else:
        msg = "Bot-A test ping"
    ok = send_text(msg)
    print("ok:", ok)
