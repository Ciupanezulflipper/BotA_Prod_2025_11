#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
status_cmd.py — sends a periodic heartbeat with system + bot health.
Requires TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in environment (sourced by the launcher).
"""

import os, time, json, shutil, subprocess, socket
from datetime import datetime, timezone
from pathlib import Path

# ---------- Config ----------
HEARTBEAT_SEC = int(os.getenv("STATUS_HEARTBEAT_SEC", "900"))  # default 15 min
RUNNER_LOCK = Path("/data/data/com.termux/files/usr/tmp/runner.lock")  # your runner lock path
LOG_DIR = Path.home() / "bot-a" / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG = LOG_DIR / "statusd.log"

BOT_NAME = os.getenv("BOT_NAME", "statusd")

# ---------- Telegram ----------
def tg_send(text: str, parse_mode="HTML"):
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        log(f"Missing TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID in env")
        return False
    import urllib.request, urllib.parse
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    data = urllib.parse.urlencode(
        {"chat_id": chat_id, "text": text, "parse_mode": parse_mode, "disable_web_page_preview": "true"}
    ).encode("utf-8")
    for attempt in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, data=data), timeout=20) as r:
                if r.status == 200:
                    return True
        except Exception as e:
            log(f"tg_send attempt {attempt+1} failed: {e}")
            time.sleep(2 * (attempt + 1))
    return False

# ---------- Logging ----------
def log(msg: str):
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("a") as f:
        f.write(f"{ts} [INFO] {msg}\n")

# ---------- Metrics ----------
def loadavg_1m() -> float:
    try:
        return os.getloadavg()[0]
    except Exception:
        try:
            with open("/proc/loadavg") as f:
                return float(f.read().split()[0])
        except Exception:
            return -1.0

def mem_free_pct() -> float:
    try:
        mem = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":")
                mem[k.strip()] = int(v.strip().split()[0])  # kB
        total = mem.get("MemTotal", 0)
        avail = mem.get("MemAvailable", 0)
        if total > 0:
            return round(100.0 * avail / total, 1)
    except Exception:
        pass
    return -1.0

def disk_free_pct() -> float:
    try:
        du = shutil.disk_usage(str(Path.home()))
        return round(100.0 * du.free / du.total, 1)
    except Exception:
        return -1.0

def uptime_hm() -> str:
    try:
        with open("/proc/uptime") as f:
            secs = float(f.read().split()[0])
        h = int(secs // 3600); m = int((secs % 3600) // 60)
        return f"{h}h {m}m"
    except Exception:
        return "n/a"

def count_proc(keyword: str) -> int:
    try:
        out = subprocess.check_output(["ps", "-ef"], text=True, timeout=5)
        return sum(1 for ln in out.splitlines() if keyword in ln and "grep" not in ln)
    except Exception:
        return -1

def lock_age(RUNNER_LOCK: Path) -> str:
    if RUNNER_LOCK.exists():
        age = (datetime.now(timezone.utc) - datetime.fromtimestamp(RUNNER_LOCK.stat().st_mtime, tz=timezone.utc))
        h = age.total_seconds() // 3600
        m = (age.total_seconds() % 3600) // 60
        return f"{int(h)}h {int(m)}m"
    return "missing"

def fmt_float(x: float) -> str:
    return "n/a" if x < 0 else f"{x:.1f}"

# ---------- Message ----------
def build_message():
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    host = socket.gethostname()

    msg = []
    msg.append("✅ <b>Heartbeat</b>")
    msg.append(f"🕒 <code>{now}</code>")
    msg.append("")
    # System
    msg.append("🧠 <b>System</b>")
    msg.append(f"• Host: <code>{host}</code>")
    msg.append(f"• Uptime: <code>{uptime_hm()}</code>")
    msg.append(f"• CPU load (1m): <code>{fmt_float(loadavg_1m())}</code>")
    msg.append(f"• RAM free: <code>{fmt_float(mem_free_pct())}%</code>")
    msg.append(f"• Disk free: <code>{fmt_float(disk_free_pct())}%</code>")
    # Bot
    msg.append("")
    msg.append("🤖 <b>Bot</b>")
    msg.append(f"• statusd: <code>running</code>")
    msg.append(f"• python procs: <code>{count_proc('python')}</code>")
    msg.append(f"• runner.lock age: <code>{lock_age(RUNNER_LOCK)}</code>")
    # Next
    msg.append("")
    msg.append("⏭️ <b>Next</b>")
    msg.append(f"• Next heartbeat in: <code>{HEARTBEAT_SEC//60} min</code>")
    return "\n".join(msg)

# ---------- Daemon ----------
def run_once():
    text = build_message()
    ok = tg_send(text)
    log(f"Heartbeat sent to Telegram, ok={ok}")

def daemon():
    log("statusd daemon starting …")
    # confirm env
    log(f"Env seen: TOKEN={'True' if os.getenv('TELEGRAM_BOT_TOKEN') else 'False'} "
        f"CHAT_ID={'True' if os.getenv('TELEGRAM_CHAT_ID') else 'False'}")
    while True:
        try:
            run_once()
        except Exception as e:
            log(f"run_once error: {e}")
        time.sleep(HEARTBEAT_SEC)

if __name__ == "__main__":
    import sys
    if "--daemon" in sys.argv:
        daemon()
    else:
        run_once()
