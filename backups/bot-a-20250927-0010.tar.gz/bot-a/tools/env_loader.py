#!/usr/bin/env python3
import os
from pathlib import Path

ENV_PATH = Path.home() / "bot-a" / ".env"

# Map any legacy/alternative names -> canonical names expected by code
ALIASES = {
    # TwelveData
    "TWELVE_DATA_API_KEY": "TWELVEDATA_TOKEN",
    "TD_KEY": "TWELVEDATA_TOKEN",
    # Alpha Vantage
    "ALPHA_VANTAGE_API_KEY": "ALPHAVANTAGE_KEY",
    "ALPHAVANTAGE_API_KEY": "ALPHAVANTAGE_KEY",
    # Finnhub
    "FINNHUB_API_KEY": "FINNHUB_TOKEN",
}

def _parse_env_lines(text: str):
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        yield k.strip(), v.strip()

def ensure_env():
    """
    Load ~/bot-a/.env into os.environ and normalize keys so the rest of the
    bot can reliably read:
      - FINNHUB_TOKEN
      - TWELVEDATA_TOKEN
      - ALPHAVANTAGE_KEY
    """
    if ENV_PATH.exists():
        try:
            content = ENV_PATH.read_text(encoding="utf-8", errors="ignore")
            for k, v in _parse_env_lines(content):
                if k not in os.environ:
                    os.environ[k] = v
        except Exception:
            pass  # don't crash if .env unreadable

    # Normalize aliases to canonical names
    for src, dst in ALIASES.items():
        v = os.environ.get(dst) or os.environ.get(src)
        if v:
            os.environ[dst] = v

    # Sanity: if canonical missing but present in popular alternates, set it
    # (covered by ALIASES above)

# Auto-run when imported
ensure_env()
