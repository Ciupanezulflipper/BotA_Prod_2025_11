#!/usr/bin/env python3
# market_hours.py — UTC-true FX guard + DST-safe session clocks
from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

# City sessions defined by "their" local open hour
_CITY_SESSIONS = [
    ("Sydney", ZoneInfo("Australia/Sydney"), time(8,0)),
    ("Tokyo",  ZoneInfo("Asia/Tokyo"),       time(9,0)),
    ("London", ZoneInfo("Europe/London"),    time(8,0)),
    ("NewYork",ZoneInfo("America/New_York"), time(8,0)),
]

def _next_local_open(city_tz: ZoneInfo, open_t: time, now_utc: datetime) -> datetime:
    """Return the next local open (>= now) for a city, converted to UTC, skipping weekends."""
    now_local = now_utc.astimezone(city_tz)
    # start from "today at open", else tomorrow, skipping Sat/Sun (Mon=0 .. Sun=6)
    for add in range(0, 8):
        day = (now_local + timedelta(days=add)).date()
        # market business days Mon..Fri
        if (day.weekday() <= 4):
            dt_local = datetime.combine(day, open_t, tzinfo=city_tz)
            dt_utc = dt_local.astimezone(timezone.utc)
            if dt_utc >= now_utc:
                return dt_utc
    # Fallback worst case
    return (now_utc + timedelta(days=1)).replace(minute=0, second=0, microsecond=0)

def fx_market_state(now_utc: datetime | None = None):
    """Return dict with FX open/closed and next session UTC datetimes."""
    if now_utc is None:
        now_utc = datetime.now(timezone.utc)

    wd = now_utc.weekday()  # Mon=0 ... Sun=6
    hm = now_utc.time()

    # FX 24x5: open from Sunday 22:00 UTC until Friday 22:00 UTC
    is_open = (
        (wd in (0,1,2,3)) or
        (wd == 4 and hm < time(22,0)) or
        (wd == 6 and hm >= time(22,0))  # Sunday after 22:00 UTC
    )

    if not is_open:
        # next global open is the *next* Sunday 22:00 UTC
        days_ahead = (6 - wd) % 7  # how many days to Sunday
        next_sun = (now_utc + timedelta(days=days_ahead)).replace(hour=22, minute=0, second=0, microsecond=0)
        if next_sun <= now_utc:
            next_sun += timedelta(days=7)
        next_open_utc = next_sun
    else:
        next_open_utc = None  # already open

    sessions = []
    for name, tz, opent in _CITY_SESSIONS:
        nxt = _next_local_open(tz, opent, now_utc)
        sessions.append((name, nxt))

    # Sort by soonest
    sessions.sort(key=lambda x: x[1])
    return {
        "is_open": is_open,
        "next_global_open_utc": next_open_utc,
        "sessions_utc": sessions,  # list of (name, dt_utc)
    }

def fmt_eta(dt_future_utc: datetime, now_utc: datetime | None = None) -> str:
    if now_utc is None:
        now_utc = datetime.now(timezone.utc)
    delta = dt_future_utc - now_utc
    if delta.total_seconds() < 0:
        return "now"
    h = int(delta.total_seconds() // 3600)
    m = int((delta.total_seconds() % 3600) // 60)
    return f"{h}h {m}m"
