#!/usr/bin/env python3
"""
EURUSD M15 runner (fetch + analyze + Telegram) for Termux/Linux

Data providers used in this order:
  1) TwelveData   (env: TWELVEDATA_KEY or TWELVE_DATA_API_KEY)
  2) Finnhub      (env: FINNHUB_API_KEY)
  3) EODHD        (env: EODHD_API_KEY)
  4) Polygon      (env: POLYGON_API_KEY)
  5) Yahoo (yfinance) — last resort, often flaky for FX; keep at end

Telegram (optional):
  TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

Gates (env overrides):
  CONF_MIN (float, default 1.5)
  THROTTLE_SEC (int, default 300)
  LOOP_SEC (int, default 60)

Writes CSV: eurusd_m15.csv  (cols: timestamp,open,high,low,close,volume)
"""

import os, sys, time, math, json, traceback
from datetime import datetime, timezone
import requests
import pandas as pd
import numpy as np

# ---------- Config ----------
PAIR        = "EURUSD"
TIMEFRAME   = "M15"
CSV_FILE    = os.getenv("CSV_FILE", "eurusd_m15.csv")

CONF_MIN     = float(os.getenv("CONF_MIN", "1.5"))
THROTTLE_SEC = int(os.getenv("THROTTLE_SEC", "300"))
LOOP_SEC     = int(os.getenv("LOOP_SEC", "60"))

TG_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN") or os.getenv("BOT_TOKEN")
TG_CHAT  = os.getenv("TELEGRAM_CHAT_ID")   or os.getenv("CHAT_ID")

# ---------- Utils ----------
def log(*a): print(*a, flush=True)

def to_df_ohlc(rows):
    """rows = list of dicts with keys: timestamp, open, high, low, close, volume"""
    df = pd.DataFrame(rows)
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df = df.sort_values("timestamp").drop_duplicates("timestamp")
    # numeric
    for c in ["open","high","low","close","volume"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna()
    return df

def save_csv(df):
    df.to_csv(CSV_FILE, index=False, float_format="%.5f")

def rsi(series, length=14):
    delta = series.diff()
    up = delta.clip(lower=0.0)
    down = -delta.clip(upper=0.0)
    roll_up = up.ewm(alpha=1/length, adjust=False).mean()
    roll_down = down.ewm(alpha=1/length, adjust=False).mean()
    rs = roll_up / (roll_down + 1e-12)
    return 100 - (100 / (1 + rs))

def ema(series, length):
    return series.ewm(span=length, adjust=False).mean()

def macd(series, fast=12, slow=26, signal=9):
    macd_line = ema(series, fast) - ema(series, slow)
    signal_line = ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist

def adx(df, length=14):
    # True Range
    high = df["high"]; low = df["low"]; close = df["close"]
    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low),
        (high - prev_close).abs(),
        (low - prev_close).abs()
    ], axis=1).max(axis=1)

    up_move = high.diff()
    down_move = -low.diff()

    plus_dm  = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)

    atr = pd.Series(tr).ewm(alpha=1/length, adjust=False).mean()
    plus_di  = 100 * pd.Series(plus_dm).ewm(alpha=1/length, adjust=False).mean()  / (atr + 1e-12)
    minus_di = 100 * pd.Series(minus_dm).ewm(alpha=1/length, adjust=False).mean() / (atr + 1e-12)

    dx = 100 * ( (plus_di - minus_di).abs() / ((plus_di + minus_di) + 1e-12) )
    adx_val = dx.ewm(alpha=1/length, adjust=False).mean()
    return adx_val

# ---------- Providers ----------
def fetch_twelvedata():
    key = os.getenv("TWELVEDATA_KEY") or os.getenv("TWELVE_DATA_API_KEY")
    if not key: 
        return None, "No TWELVEDATA_KEY"
    url = "https://api.twelvedata.com/time_series"
    p = {
        "symbol": "EUR/USD",
        "interval": "15min",
        "outputsize": "500",
        "apikey": key
    }
    r = requests.get(url, params=p, timeout=30)
    if r.status_code != 200: return None, f"HTTP {r.status_code}"
    js = r.json()
    if "values" not in js: return None, f"Bad payload: {str(js)[:120]}"
    rows = []
    for v in js["values"]:
        rows.append({
            "timestamp": v["datetime"],
            "open":  v["open"],
            "high":  v["high"],
            "low":   v["low"],
            "close": v["close"],
            "volume": v.get("volume", "0")
        })
    return to_df_ohlc(rows), "OK"

def fetch_finnhub():
    key = os.getenv("FINNHUB_API_KEY")
    if not key: return None, "No FINNHUB_API_KEY"
    # OANDA symbol naming works for Finnhub FX
    symbol = "OANDA:EUR_USD"
    now = int(time.time())
    frm = now - 500*15*60
    url = "https://finnhub.io/api/v1/forex/candle"
    p = {"symbol": symbol, "resolution":"15", "from":frm, "to":now, "token":key}
    r = requests.get(url, params=p, timeout=30)
    if r.status_code != 200: return None, f"HTTP {r.status_code}"
    js = r.json()
    if js.get("s") != "ok": return None, f"Finnhub s={js.get('s')}"
    rows = []
    for t,o,h,l,c,v in zip(js["t"], js["o"], js["h"], js["l"], js["c"], js["v"]):
        rows.append({
            "timestamp": datetime.utcfromtimestamp(t).replace(tzinfo=timezone.utc),
            "open": o, "high": h, "low": l, "close": c, "volume": v
        })
    return to_df_ohlc(rows), "OK"

def fetch_eodhd():
    key = os.getenv("EODHD_API_KEY")
    if not key: return None, "No EODHD_API_KEY"
    # EODHD FX: pair.EOD, example EURUSD.FOREX
    url = f"https://eodhd.com/api/real-time/EURUSD.FOREX"
    # EODHD doesn’t give granular intraday for free—skip if not available
    return None, "Not available on free plan"

def fetch_polygon():
    key = os.getenv("POLYGON_API_KEY")
    if not key: return None, "No POLYGON_API_KEY"
    # Polygon FX aggregations are paid in most plans; we’ll skip to avoid 401
    return None, "Likely paid-only on current plan"

def fetch_yahoo():
    try:
        import yfinance as yf
        t = yf.Ticker("EURUSD=X")
        df = t.history(period="7d", interval="15m", auto_adjust=False, prepost=False, repair=True)
        if df is None or df.empty: return None, "empty"
        df = df.dropna()
        df = df.rename(columns={"Open":"open","High":"high","Low":"low","Close":"close","Volume":"volume"})
        df = df.reset_index().rename(columns={"Datetime":"timestamp"})
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        df = df[["timestamp","open","high","low","close","volume"]]
        return to_df_ohlc(df.to_dict("records")), "OK"
    except Exception as e:
        return None, f"err {e}"

PROVIDERS = [
    ("TwelveData", fetch_twelvedata),
    ("Finnhub",    fetch_finnhub),
    ("EODHD",      fetch_eodhd),
    ("Polygon",    fetch_polygon),
    ("Yahoo",      fetch_yahoo),
]

def fetch_multi():
    """Try providers in order; return df or None."""
    for name, fn in PROVIDERS:
        log(f"[FETCH] Trying {name} …")
        try:
            df, status = fn()
        except Exception as e:
            status = f"EXC {e}"
            df = None
        if df is not None and len(df) >= 50:
            save_csv(df)
            log(f"[FETCH] {name} OK: {len(df)} rows -> {CSV_FILE}")
            return df
        else:
            log(f"[FETCH] {name} failed: {status}")
    log("[FETCH] All providers failed.")
    return None

# ---------- Telegram ----------
def send_telegram(msg):
    if not (TG_TOKEN and TG_CHAT):
        return False
    try:
        url = f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage"
        data = {"chat_id": TG_CHAT, "text": msg, "parse_mode":"HTML", "disable_web_page_preview": True}
        r = requests.post(url, data=data, timeout=20)
        return r.status_code == 200
    except Exception:
        return False

def fmt_line(res):
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    notes = " ; ".join(res["notes"])
    return (f"{stamp} | {PAIR} {TIMEFRAME} {res['direction']} | "
            f"Score {res['score']:.2f} | "
            f"RSI {res['rsi']:.1f} • ADX {res['adx']:.1f} • ΔMACD {res['macd_hist']:.6f} | "
            f"{notes}")

def fmt_tg(res):
    n = " ; ".join(res["notes"])
    return (f"⚡ <b>{PAIR} {TIMEFRAME} {res['direction']}</b>\n"
            f"Score <b>{res['score']:.2f}</b>\n"
            f"RSI {res['rsi']:.1f} • ADX {res['adx']:.1f} • ΔMACD {res['macd_hist']:.6f}\n"
            f"{n}")

# ---------- Analysis ----------
def analyze(df):
    # keep last 300 bars for speed
    df = df.tail(300).copy()
    close = df["close"]

    r = rsi(close, 14)
    macd_line, macd_signal, macd_hist = macd(close, 12, 26, 9)
    a = adx(df, 14)

    df["rsi"] = r
    df["macd_hist"] = macd_hist
    df["adx"] = a

    last = df.iloc[-1]
    rsi_v = float(last["rsi"])
    adx_v = float(last["adx"])
    macd_h = float(last["macd_hist"])

    # basic rules
    dirn = "FLAT"
    score = 0.0
    notes = []

    # RSI bands
    if rsi_v >= 65: score += 0.6; notes.append("RSI≥65")
    elif rsi_v <= 35: score += 0.6; notes.append("RSI≤35")
    else: notes.append("RSI mid")

    # ADX strength
    if adx_v >= 22: score += 0.6; notes.append("ADX≥22")
    else: notes.append("ADX weak")

    # MACD hist sign
    if macd_h > 0: notes.append("ΔMACD>0")
    elif macd_h < 0: notes.append("ΔMACD<0")
    else: notes.append("ΔMACD≈0")

    # direction
    if score >= CONF_MIN:
        if rsi_v >= 65 and macd_h < 0:
            dirn = "SELL"
        elif rsi_v <= 35 and macd_h > 0:
            dirn = "BUY"
        else:
            dirn = "FLAT"

    return {
        "direction": dirn,
        "score": score,
        "rsi": rsi_v,
        "adx": adx_v,
        "macd_hist": macd_h,
        "notes": notes,
        "last_ts": df["timestamp"].iloc[-1]
    }

# ---------- Main loop ----------
def main():
    log(f"[START] {PAIR} {TIMEFRAME} | Python {sys.version.split()[0]}")
    log(f"[INFO] CONF_MIN={CONF_MIN:.2f}  THROTTLE_SEC={THROTTLE_SEC}  LOOP_SEC={LOOP_SEC}")

    last_send_ts = 0.0
    last_candle_ts = None
    consecutive_tg_err = 0

    # ensure we have data at boot
    df = None
    if os.path.exists(CSV_FILE):
        try:
            df = pd.read_csv(CSV_FILE)
            if len(df) < 50:
                df = None
        except Exception:
            df = None
    if df is None:
        df = fetch_multi()
        if df is None:
            log("[FATAL] No data available on start.")
            sys.exit(2)

    while True:
        try:
            # 1) refresh data (cheap: providers already rate-limited)
            df2 = fetch_multi()
            if df2 is not None:
                df = df2

            # 2) analyze
            res = analyze(df)
            print(fmt_line(res))

            # 3) send signal only once per new candle and pass gates
            new_candle = (last_candle_ts is None) or (res["last_ts"] != last_candle_ts)
            should_send = (
                res["direction"] != "FLAT" and
                res["score"] >= CONF_MIN and
                new_candle and
                (time.time() - last_send_ts) >= THROTTLE_SEC
            )

            if should_send:
                ok = send_telegram(fmt_tg(res))
                last_send_ts = time.time()
                if not ok:
                    consecutive_tg_err += 1
                    if consecutive_tg_err >= 5:
                        log("[FATAL] Too many Telegram errors; exiting to be safe.")
                        sys.exit(4)
                else:
                    consecutive_tg_err = 0

            last_candle_ts = res["last_ts"]
            time.sleep(LOOP_SEC)

        except KeyboardInterrupt:
            print("\n[STOP] User interrupt")
            break
        except Exception as e:
            print("[ERROR]", e)
            traceback.print_exc(limit=1)
            time.sleep(5)

if __name__ == "__main__":
    main()
