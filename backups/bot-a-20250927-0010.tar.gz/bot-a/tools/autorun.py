#!/usr/bin/env python3
"""
autorun.py — post signals to Telegram and journal them.

- Respects OPEN_UTC / CLOSE_UTC window unless overridden by env.
- Uses signals.engine_v2b.score_symbol() to compute signals.
- Journals every run to ~/bot-a/logs/signals-YYYYMMDD.csv
- Sends Telegram text + optional chart (if available).
- Triggers a lightweight auto-audit when new posts were sent.

Env (.env)
----------
TELEGRAM_BOT_TOKEN=xxxxx
TELEGRAM_CHAT_ID=xxxxx
OPEN_UTC=07            # inclusive hour UTC (00–23)
CLOSE_UTC=21           # exclusive hour UTC (01–24)
BASE_TF=5min
WATCHLIST=EURUSD,XAUUSD
SCORE_MIN=35
JOURNAL_DIR=~/bot-a/logs
CADENCE_MIN=30
"""

from __future__ import annotations
import os, csv, sys, uuid, pathlib, datetime as dt
from typing import Dict, Any, Optional, Sequence, Tuple

# ---------- utilities ----------
def env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()

def utcnow() -> dt.datetime:
    # return naive UTC (stable for CSV); aware used only for hours check
    return dt.datetime.utcnow()

def utcnow_aware() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)

def _run_id() -> str:
    return uuid.uuid4().hex[:8]

def _ensure_dir(path: str) -> None:
    p = pathlib.Path(os.path.expanduser(path))
    p.mkdir(parents=True, exist_ok=True)

# ---------- CSV journal ----------
def _csv_path(jdir: str) -> pathlib.Path:
    today = utcnow().strftime("%Y%m%d")
    return pathlib.Path(os.path.expanduser(jdir)) / f"signals-{today}.csv"

def _append_csv(row: Sequence[Any]) -> None:
    jdir = env("JOURNAL_DIR", os.path.expanduser("~/bot-a/logs"))
    _ensure_dir(jdir)
    path = _csv_path(jdir)
    new_file = not path.exists()
    with path.open("a", newline="") as f:
        w = csv.writer(f)
        if new_file:
            w.writerow([
                "run_id","time_utc","symbol","tf","type","score","bias",
                "entry","stop","target","why","cadence_min","watchlist","engine"
            ])
        w.writerow(list(row))

# ---------- provider + engine imports ----------
# data providers facade
from data import providers
# scoring engine (v2b)
from signals.engine_v2b import score_symbol as score_v2

# telegram helpers (text + photo, optional)
try:
    from tools.tg import tg_send_text, tg_send_photo
except Exception:
    def tg_send_text(chat_id: Optional[str], text: str) -> Tuple[bool,str]:
        return False, "tools.tg not installed"
    def tg_send_photo(chat_id: Optional[str], png_bytes: bytes, caption: str = "", parse_mode: Optional[str]=None) -> Tuple[bool,str]:
        return False, "tools.tg not installed"

# chart generator (optional)
try:
    from tools.charts import render_chart_png  # def render_chart_png(symbol, tf) -> bytes|None
except Exception:
    def render_chart_png(symbol: str, tf: str) -> Optional[bytes]:
        return None

# ---------- posting helpers ----------
CAPTION_MAX = 1024

def _format_signal_text(symbol: str, tf: str, res: Dict[str, Any]) -> str:
    side = "Bullish" if (res.get("bias","") == "Bullish") else ("Bearish" if res.get("bias","")=="Bearish" else "NEUTRAL")
    score = int(res.get("score") or 0)
    why = res.get("note") or "-"
    trend = res.get("trend", 0); mom = res.get("mom", 0)
    vol = res.get("vol", 0); struct = res.get("struct", 0); volat = res.get("volat", 0)
    entry = res.get("entry"); stop = res.get("stop"); target = res.get("target")

    lines = []
    lines.append(f"📈 {symbol} — {side}")
    lines.append(f"<i>Time:</i> {utcnow().strftime('%Y-%m-%d %H:%M:%SZ')}  •  <i>TF:</i> {tf}")
    lines.append("")
    lines.append(f"• <b>Signal</b>: {score}/100 (HOLD)")
    lines.append(f"  — trend {trend}, mom {mom}, vol {vol}, struct {struct}, volat {volat}")
    lines.append("")
    if entry is not None and stop is not None and target is not None:
        lines.append("• <b>Trade Plan</b>")
        lines.append(f"  — <b>Entry</b>: {entry}")
        lines.append(f"  — <b>Stop</b>:  {stop}")
        lines.append(f"  — <b>Target</b>: {target}  (RR 2.0)")
        lines.append("")
    lines.append(f"• <b>Why?</b> {why}")
    lines.append("")
    lines.append("• <b>Risk</b>: suggest 0.5%–1.0%  •  <b>Session</b>: auto")
    return "\n".join(lines)

def _post_signal(symbol: str, tf: str, res: Dict[str, Any], run_id: str, watchlist: Sequence[str]) -> int:
    score = int(res.get("score") or 0)
    bias  = res.get("bias") or ""
    entry = res.get("entry"); stop = res.get("stop"); target = res.get("target")
    why   = res.get("note") or ""

    # journal first
    _append_csv([
        run_id, utcnow().strftime("%Y-%m-%d %H:%M:%SZ"),
        symbol, tf, "ok", score, {"Bullish":1, "Bearish":-1}.get(bias, 0),
        entry if entry is not None else "",
        stop if stop is not None else "",
        target if target is not None else "",
        why, env("CADENCE_MIN","30"), ",".join(watchlist), "v2b"
    ])

    # enforce threshold
    score_min = int(env("SCORE_MIN","35") or "35")
    if score < score_min:
        return 0

    text = _format_signal_text(symbol, tf, res)
    ok, why_send = tg_send_text(None, text)
    if not ok:
        _append_csv([run_id, utcnow().strftime("%Y-%m-%d %H:%M:%SZ"),
                     symbol, tf, "error", "", "", "", "", "", f"telegram text failed: {why_send}",
                     env("CADENCE_MIN","30"), ",".join(watchlist), "v2b"])
        return 0

    # try chart (optional)
    png = render_chart_png(symbol, tf)
    if png:
        caption = text[:CAPTION_MAX-1]
        tg_send_photo(None, png, caption, parse_mode="HTML")

    return 1

# ---------- session window ----------
def _within_session() -> bool:
    try:
        h_open  = int(env("OPEN_UTC","07") or "7")
        h_close = int(env("CLOSE_UTC","21") or "21")
    except Exception:
        return True
    nowh = int(utcnow_aware().strftime("%H"))
    if h_open <= h_close:
        return (h_open <= nowh < h_close)
    # wrap-around (e.g., 20..04)
    return not (h_close <= nowh < h_open)

# ---------- auto-audit trigger ----------
def _auto_audit_if_needed(posted_total: int) -> None:
    if posted_total <= 0:
        return
    try:
        import subprocess, shlex, os as _os
        py = sys.executable or "python3"
        cmd = f'{py} {_os.path.expanduser("~/bot-a/tools/audit.py")} --n 3 --lookahead 12 --write'
        subprocess.Popen(shlex.split(cmd), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

# ---------- trade plan (fallbacks OK if engine returns them) ----------
def _trade_plan_from_engine(symbol: str, tf: str, res: Dict[str,Any]) -> Dict[str,Any]:
    # Keep whatever engine provided (entry/stop/target may be absent when no candles)
    return {
        "entry":  res.get("entry"),
        "stop":   res.get("stop"),
        "target": res.get("target")
    }

# ---------- main ----------
def main() -> int:
    # config
    jdir = env("JOURNAL_DIR", os.path.expanduser("~/bot-a/logs"))
    _ensure_dir(jdir)

    watchlist = [s.strip().upper() for s in env("WATCHLIST","EURUSD,XAUUSD").split(",") if s.strip()]
    tf        = env("BASE_TF","5min")
    cadence   = env("CADENCE_MIN","30")
    run_id    = _run_id()

    # heartbeat
    _append_csv([run_id, utcnow().strftime("%Y-%m-%d %H:%M:%SZ"),
                 "", tf, "heartbeat", "", "", "", "", "", "",
                 cadence, ",".join(watchlist), "v2b"])

    # session gate
    if not _within_session():
        _append_csv([run_id, utcnow().strftime("%Y-%m-%d %H:%M:%SZ"),
                     "", tf, "skip", "", "", "", "", "", "outside trading hours",
                     cadence, ",".join(watchlist), "v2b"])
        return 0

    # sanity ping (provider online?)
    name, ok, code, detail = providers.ping_any()
    _append_csv([run_id, utcnow().strftime("%Y-%m-%d %H:%M:%SZ"),
                 "", "", "ping", "", "", "", "", "", f"{name} ok={ok} code={code} {detail}",
                 cadence, ",".join(watchlist), "v2b"])
    # continue even if ping fails; post_one will guard

    posted_total = 0
    for sym in watchlist:
        # compute signal
        try:
            res = score_v2(sym, tf=tf, limit=300)
        except Exception as e:
            _append_csv([run_id, utcnow().strftime("%Y-%m-%d %H:%M:%SZ"),
                         sym, tf, "error", "", "", "", "", "",
                         f"engine error: {e}", cadence, ",".join(watchlist), "v2b"])
            continue

        # enrich with trade plan (if any)
        plan = _trade_plan_from_engine(sym, tf, res)
        res.update(plan)

        posted_total += _post_signal(sym, tf, res, run_id, watchlist)

    # auto-audit best effort
    _auto_audit_if_needed(posted_total)

    # non-fatal if none posted
    return 0 if posted_total > 0 else 0

# --------------- entry ---------------
if __name__ == "__main__":
    raise SystemExit(main())
