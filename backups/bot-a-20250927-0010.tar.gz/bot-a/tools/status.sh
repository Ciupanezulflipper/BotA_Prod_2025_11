#!/usr/bin/env bash
# tools/status.sh
# Show Bot-A health at a glance: running loops, latest logs, today’s counts.

set -euo pipefail

PY_HOME="${HOME}/bot-a"
LOG_DIR="${HOME}/.bot-a/logs"
RUN_DIR="${HOME}/.bot-a/run"

mkdir -p "${LOG_DIR}" "${RUN_DIR}"

mask() {
  # mask long secrets: keep first 6 and last 4 chars
  local s="${1:-}"
  local n=${#s}
  if (( n <= 10 )); then
    printf "%s" "$s"
  else
    printf "%s…%s" "${s:0:6}" "${s: -4}"
  fi
}

pid_status() {
  local name="$1" file="$2"
  if [[ -f "$file" ]]; then
    local pid; pid=$(cat "$file" 2>/dev/null || true)
    if kill -0 "$pid" 2>/dev/null; then
      # try to get elapsed time
      local et="?"
      if ps -o etime= -p "$pid" >/dev/null 2>&1; then
        et=$(ps -o etime= -p "$pid" | awk '{print $1}')
      fi
      echo "• ${name}: RUNNING (pid ${pid}, up ${et})"
    else
      echo "• ${name}: STALE (pid ${pid}), removing pidfile"
      rm -f "$file"
    fi
  else
    echo "• ${name}: stopped"
  fi
}

latest_file() {
  # print latest file path for given glob
  local g="$1"
  ls -1t ${g} 2>/dev/null | head -n1 || true
}

last_stamp() {
  # read last banner line "==========" from a log
  local f="$1"
  grep -a "==========" "$f" 2>/dev/null | tail -n1 | sed 's/^=* *//; s/ *=*$//'
}

today_counts() {
  # rough counts from today’s runner log
  local f="$1"
  [[ -z "$f" ]] && { echo "   (no runner log)"; return; }
  local day; day=$(date -u +%Y%m%d)
  local file_day; file_day=$(basename "$f" | sed -n 's/[^0-9]*\([0-9]\{8\}\).*/\1/p')
  if [[ "$day" != "$file_day" ]]; then
    echo "   (latest not today: $(basename "$f"))"
  fi
  local sent skip prn err
  sent=$(grep -a "✅ sent" "$f" 2>/dev/null | wc -l | awk '{print $1}')
  skip=$(grep -a -i "⏭️ skip" "$f" 2>/dev/null | wc -l | awk '{print $1}')
  prn=$(grep -a "🖨️ printed" "$f" 2>/dev/null | wc -l | awk '{print $1}')
  err=$(grep -a -i "❌ error" "$f" 2>/dev/null | wc -l | awk '{print $1}')
  echo "   today: sent ${sent} | skipped ${skip} | printed ${prn} | errors ${err}"
}

echo ""
echo "=== Bot-A Status ($(date -u '+%Y-%m-%d %H:%M:%S UTC')) ==="

# env check (masked)
tok="${TELEGRAM_BOT_TOKEN:-}"
cid="${TELEGRAM_CHAT_ID:-}"
[[ -n "$tok" ]] && echo "• Telegram token: $(mask "$tok")" || echo "• Telegram token: MISSING"
[[ -n "$cid" ]] && echo "• Telegram chat : $cid"          || echo "• Telegram chat : MISSING"

# loops
pid_status "signal run loop" "${RUN_DIR}/signal_runner.pid"
pid_status "digest loop"      "${RUN_DIR}/digest_loop.pid"
pid_status "error monitor"    "${RUN_DIR}/error_monitor.pid"

# latest logs
runner_log=$(latest_file "${LOG_DIR}/runner-*.log")
digest_log=$(latest_file "${LOG_DIR}/digest-*.log")

echo ""
if [[ -n "$runner_log" ]]; then
  echo "• Latest runner log: $(basename "$runner_log")"
  echo "   last: $(last_stamp "$runner_log")"
  today_counts "$runner_log"
else
  echo "• Latest runner log: (none)"
fi

if [[ -n "$digest_log" ]]; then
  echo "• Latest digest log: $(basename "$digest_log")"
  echo "   last: $(last_stamp "$digest_log")"
else
  echo "• Latest digest log: (none)"
fi

# disk usage
echo ""
du -sh "${LOG_DIR}" 2>/dev/null | awk '{print "• Log dir size: "$1" ("$2")"}' || echo "• Log dir size: n/a"
echo ""

# tail samples
[[ -n "$runner_log" ]] && { echo "--- tail runner ---"; tail -n 8 "$runner_log"; echo ""; }
[[ -n "$digest_log" ]] && { echo "--- tail digest ---"; tail -n 8 "$digest_log"; echo ""; }

exit 0
