#!/usr/bin/env python3
import json, os, time, sys
MAX = float(os.getenv("MAX_SPREAD_PIPS","2.0"))
PATH = os.path.expanduser("~/bot-a/data/spread.json")
def check():
    try:
        with open(PATH) as f: data=json.load(f)
        eur = data.get("EURUSD") or data.get("EUR/USD") or {}
        pips = float(eur.get("spread_pips", 999.0))
        ts = eur.get("ts") or int(time.time())
        ok = pips <= MAX
        return ok, pips, ts
    except Exception as e:
        return False, 999.0, 0
if __name__ == "__main__":
    ok,pips,ts = check()
    if not ok:
        print(f"BLOCK spread>{MAX} pips (got {pips})")
        sys.exit(2)
    print(f"OK spread {pips}")
