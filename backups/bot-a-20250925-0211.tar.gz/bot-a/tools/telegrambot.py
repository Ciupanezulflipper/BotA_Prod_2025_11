#!/usr/bin/env python3
import os, json, urllib.request, urllib.parse

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
CHAT_ID   = os.getenv("CHAT_ID", "")

def send_telegram(text: str) -> bool:
    """Send a plain text message via Telegram. Returns True on 200 OK.
       If tokens are missing, just log and return False (no crash)."""
    if not BOT_TOKEN or not CHAT_ID:
        print("[TG] BOT_TOKEN/CHAT_ID not set; would send:\n", text)
        return False
    try:
        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
        data = urllib.parse.urlencode({
            "chat_id": CHAT_ID,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": "true"
        }).encode("utf-8")
        with urllib.request.urlopen(urllib.request.Request(url, data=data, method="POST"), timeout=10) as r:
            ok = (r.status == 200)
            if not ok:
                print("[TG] HTTP", r.status, r.read())
            return ok
    except Exception as e:
        print("[TG] ERR:", e)
        return False
