#!/usr/bin/env python3
import os, requests, pandas as pd, time

CSV_FILE = "eurusd_m15.csv"
API_KEY = os.getenv("FINNHUB_API_KEY", "").strip()

def fetch_and_save():
    if not API_KEY:
        print("[ERROR] No FINNHUB_API_KEY in .env")
        return 0

    # Finnhub symbol for EUR/USD
    symbol = "OANDA:EUR_USD"
    # 15-minute candles = 900 sec
    url = f"https://finnhub.io/api/v1/forex/candle?symbol={symbol}&resolution=15&from={int(time.time())-5*24*3600}&to={int(time.time())}&token={API_KEY}"
    r = requests.get(url, timeout=30)
    js = r.json()
    if js.get("s") != "ok":
        print("[ERROR] Finnhub returned", js)
        return 0

    data = []
    for t,o,h,l,c,v in zip(js["t"], js["o"], js["h"], js["l"], js["c"], js["v"]):
        data.append({
            "timestamp": pd.to_datetime(t, unit="s", utc=True),
            "open": o, "high": h, "low": l, "close": c, "volume": v
        })

    df = pd.DataFrame(data).sort_values("timestamp").tail(500)
    df.to_csv(CSV_FILE, index=False)
    print(f"[DONE] Saved {len(df)} candles to {CSV_FILE}")
    return len(df)

if __name__ == "__main__":
    fetch_and_save()
