#!/usr/bin/env python3
import pandas as pd
import numpy as np
import time
from datetime import datetime
import os, sys

from telegrambot import send_telegram          # you already created this
from fetch_candles import fetch_and_save       # <-- NEW: auto-refresh CSV

# Configuration
PAIR = "EURUSD"
TIMEFRAME = "M15"
CSV_FILE = "eurusd_m15.csv"

class TechnicalIndicators:
    @staticmethod
    def rsi(data, period=14):
        if len(data) < period + 1: return 50.0
        delta = data.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        val = rsi.iloc[-1]
        return float(val) if pd.notna(val) else 50.0

    @staticmethod
    def adx(high, low, close, period=14):
        if len(high) < period + 1: return 5.0
        tr1 = high - low
        tr2 = (high - close.shift()).abs()
        tr3 = (low - close.shift()).abs()
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        plus_dm = (high.diff()).clip(lower=0.0)
        minus_dm = (-low.diff()).clip(lower=0.0)
        plus_dm[plus_dm <= minus_dm] = 0.0
        minus_dm[minus_dm <= plus_dm] = 0.0
        tr_s = tr.rolling(period).mean()
        p_s = plus_dm.rolling(period).mean()
        m_s = minus_dm.rolling(period).mean()
        plus_di = 100 * p_s / tr_s
        minus_di = 100 * m_s / tr_s
        dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
        adx = dx.rolling(period).mean()
        val = adx.iloc[-1]
        return float(val) if pd.notna(val) else 5.0

    @staticmethod
    def macd(data, fast=12, slow=26, signal=9):
        if len(data) < slow + signal: return 0.0, 0.0, 0.0
        ema_fast = data.ewm(span=fast, adjust=False).mean()
        ema_slow = data.ewm(span=slow, adjust=False).mean()
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=signal, adjust=False).mean()
        hist = macd_line - signal_line
        return float(macd_line.iloc[-1]), float(signal_line.iloc[-1]), float(hist.iloc[-1])

def load_data():
    if not os.path.exists(CSV_FILE):
        print(f"[ERROR] Missing {CSV_FILE}")
        return None
    df = pd.read_csv(CSV_FILE)
    if df.empty:
        print("[ERROR] CSV is empty")
        return None
    # Normalize columns
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
        df = df.dropna(subset=["timestamp"])
        df = df.sort_values("timestamp")
    required = {"open","high","low","close","volume"}
    if not required.issubset(df.columns):
        print(f"[ERROR] CSV missing columns: {required - set(df.columns)}")
        return None
    return df.tail(300).copy()

def analyze_market(df):
    if df is None or len(df) < 50:
        return None
    c = df["close"]; h = df["high"]; l = df["low"]
    rsi = TechnicalIndicators.rsi(c)
    adx = TechnicalIndicators.adx(h, l, c)
    macd_line, macd_sig, macd_hist = TechnicalIndicators.macd(c)
    direction = "FLAT"
    score = 0.0
    notes = []
    # simple logic like before
    if rsi <= 35: score += 1.0; notes.append("RSI≤35")
    if adx < 18: notes.append("ADX weak")
    if abs(macd_hist) < 1e-6: notes.append("ΔMACD≈0")
    if macd_line > macd_sig: direction = "BUY"
    elif macd_line < macd_sig: direction = "SELL"
    return dict(
        price=float(c.iloc[-1]),
        rsi=float(rsi), adx=float(adx),
        macd_line=float(macd_line), macd_sig=float(macd_sig), macd_hist=float(macd_hist),
        direction=direction, score=round(score + (0.6 if direction!="FLAT" else 0.3),2),
        notes=notes
    )

def main():
    print(f"[START] Bot {PAIR} {TIMEFRAME} | Python {sys.version.split()[0]}")
    loop = 0
    while True:
        loop += 1
        print(f"\n[LOOP {loop}] ---------------------")
        # NEW: fetch fresh CSV each loop
        try:
            n = fetch_and_save()
            if n < 50:
                print("[ERROR] Too few rows after fetch; retry in 30s")
                time.sleep(30); continue
        except Exception as e:
            print(f"[ERROR] Fetch failed: {e}")
            time.sleep(30); continue

        df = load_data()
        if df is None:
            print("[ERROR] Data load failed; retry in 30s")
            time.sleep(30); continue

        res = analyze_market(df)
        if res is None:
            print("[ERROR] Analysis failed; retry in 30s")
            time.sleep(30); continue

        ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        line = (f"{ts} UTC | {PAIR} {TIMEFRAME} | {res['direction']} | "
                f"Score {res['score']:.2f} | RSI {res['rsi']:.2f} • ADX {res['adx']:.2f} "
                f"• ΔMACD {res['macd_hist']:.6f} | {' ; '.join(res['notes'])}")
        print(line)

        # Telegram alert only when not FLAT
        if res["direction"] != "FLAT":
            msg = (f"⚡ <b>{PAIR} {TIMEFRAME} {res['direction']}</b>\n"
                   f"Score {res['score']:.2f}\n"
                   f"RSI {res['rsi']:.1f} | ADX {res['adx']:.1f} | ΔMACD {res['macd_hist']:.6f}")
            send_telegram(msg)

        time.sleep(60)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[STOP] User interrupt")
